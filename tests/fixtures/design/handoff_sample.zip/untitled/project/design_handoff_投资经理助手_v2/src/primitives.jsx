// primitives.jsx — shared building blocks
const { useState, useEffect, useRef, useMemo, useCallback, useLayoutEffect, Fragment } = React;

const Icon = ({ name, size = 16, color, style, ...rest }) => (
  <i data-lucide={name} style={{ width: size, height: size, color: color || 'currentColor', display: 'inline-flex', flexShrink: 0, ...style }} {...rest} />
);

// Re-run lucide on mount so dynamically inserted <i data-lucide> elements get replaced.
const useLucide = (dep) => {
  useEffect(() => {
    if (window.lucide && window.lucide.createIcons) {
      try { window.lucide.createIcons(); } catch (e) {}
    }
  }, [dep]);
};

const Button = ({ variant = 'secondary', size = 'md', leading, trailing, children, onClick, disabled, active, style, title }) => {
  const sizes = {
    xs: { h: 22, px: 8, fs: 11, r: 4, gap: 4 },
    sm: { h: 26, px: 10, fs: 12, r: 5, gap: 5 },
    md: { h: 30, px: 12, fs: 13, r: 6, gap: 6 },
    lg: { h: 36, px: 16, fs: 13, r: 6, gap: 7 },
  }[size];
  const variants = {
    primary: { bg: 'var(--brand)', color: '#fff', border: '1px solid var(--brand)' },
    secondary: { bg: 'var(--bg-elevated)', color: 'var(--fg-primary)', border: '1px solid var(--border-default)' },
    ghost: { bg: 'transparent', color: 'var(--fg-secondary)', border: '1px solid transparent' },
    accent: { bg: 'var(--accent)', color: '#05070F', border: '1px solid var(--accent)' },
    ai: { bg: 'var(--accent-muted)', color: 'var(--accent-300)', border: '1px solid rgba(0,195,232,0.25)' },
    danger: { bg: 'var(--danger-bg)', color: '#F08080', border: '1px solid var(--danger-border)' },
  }[variant];
  const [hover, setHover] = useState(false);
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: active ? 'var(--bg-active)' : (hover && !disabled && variant === 'secondary' ? 'var(--bg-hover)' : variants.bg),
        color: variants.color, border: variants.border,
        borderRadius: sizes.r, padding: `0 ${sizes.px}px`, height: sizes.h,
        fontSize: sizes.fs, fontWeight: (variant === 'accent' || variant === 'primary') ? 500 : 500,
        fontFamily: 'var(--font-sans)', cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1, display: 'inline-flex', alignItems: 'center', gap: sizes.gap,
        whiteSpace: 'nowrap', letterSpacing: 0,
        transition: 'background var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out)', ...style,
      }}>
      {leading && <Icon name={leading} size={sizes.fs + 2} />}
      {children}
      {trailing && <Icon name={trailing} size={sizes.fs + 2} />}
    </button>
  );
};

const IconButton = ({ icon, size = 28, iconSize = 15, active, onClick, title, style, tone = 'neutral' }) => {
  const [hover, setHover] = useState(false);
  const toneColor = {
    neutral: 'var(--fg-secondary)',
    ai: 'var(--accent-400)',
    brand: 'var(--brand-300)',
  }[tone];
  return (
    <button onClick={onClick} title={title}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        width: size, height: size, borderRadius: 6,
        background: active ? 'var(--bg-active)' : (hover ? 'var(--bg-hover)' : 'transparent'),
        color: active ? 'var(--fg-primary)' : toneColor,
        border: 'none', cursor: 'pointer', display: 'inline-flex',
        alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        transition: 'background var(--dur-fast)', ...style,
      }}>
      <Icon name={icon} size={iconSize} />
    </button>
  );
};

const Badge = ({ tone = 'neutral', pill = false, dot = false, children, style }) => {
  const tones = {
    neutral: { bg: 'var(--bg-hover)', color: 'var(--fg-secondary)', border: 'var(--border-default)' },
    subtle:  { bg: 'transparent', color: 'var(--fg-tertiary)', border: 'var(--border-default)' },
    success: { bg: 'rgba(34,197,94,0.10)', color: '#55C08C', border: 'rgba(34,197,94,0.25)' },
    warning: { bg: 'rgba(245,184,64,0.10)', color: '#F5BF50', border: 'rgba(245,184,64,0.25)' },
    danger:  { bg: 'rgba(239,68,68,0.10)', color: '#F08080', border: 'rgba(239,68,68,0.25)' },
    info:    { bg: 'var(--brand-muted)', color: 'var(--brand-300)', border: 'rgba(91,108,255,0.3)' },
    ai:      { bg: 'var(--accent-muted)', color: 'var(--accent-300)', border: 'rgba(0,195,232,0.3)' },
    brand:   { bg: 'var(--brand-muted)', color: 'var(--brand-300)', border: 'rgba(91,108,255,0.3)' },
  }[tone];
  return (
    <span style={{
      background: tones.bg, color: tones.color, border: `1px solid ${tones.border}`,
      borderRadius: pill ? 9999 : 4, padding: pill ? '2px 10px' : '1px 7px',
      fontSize: 11, fontWeight: 500, display: 'inline-flex', alignItems: 'center', gap: 5,
      whiteSpace: 'nowrap', lineHeight: 1.5, ...style,
    }}>
      {dot && <span style={{ width: 6, height: 6, background: tones.color, borderRadius: '50%' }} />}
      {children}
    </span>
  );
};

const Kbd = ({ children, style }) => (
  <span style={{
    background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)',
    borderRadius: 3, padding: '1px 5px', fontSize: 10, color: 'var(--fg-secondary)',
    fontFamily: 'var(--font-mono)', letterSpacing: 0, minWidth: 14, textAlign: 'center',
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    ...style,
  }}>{children}</span>
);

const Card = ({ interactive, children, style, onClick }) => {
  const [hover, setHover] = useState(false);
  return (
    <div onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: 'var(--bg-elevated)',
        border: `1px solid ${hover && interactive ? 'var(--border-strong)' : 'var(--border-default)'}`,
        borderRadius: 8, boxShadow: 'var(--shadow-xs)',
        cursor: interactive ? 'pointer' : 'default',
        transition: 'border-color var(--dur-fast) var(--ease-out)',
        ...style,
      }}
    >{children}</div>
  );
};

const Label = ({ children, style }) => (
  <div style={{
    fontSize: 10, fontWeight: 500, color: 'var(--fg-tertiary)',
    textTransform: 'uppercase', letterSpacing: '0.08em', ...style,
  }}>{children}</div>
);

// Inline citation chip: renders as a small superscript-ish marker with tooltip.
const CitationChip = ({ n, source, onClick }) => {
  const [hover, setHover] = useState(false);
  return (
    <span
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onClick={onClick}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 3,
        background: hover ? 'var(--accent-muted)' : 'transparent',
        color: 'var(--accent-400)', border: '1px solid rgba(0,195,232,0.3)',
        borderRadius: 3, padding: '0 4px', fontSize: 10,
        fontFamily: 'var(--font-mono)', fontWeight: 500,
        cursor: 'pointer', marginLeft: 2, marginRight: 1,
        verticalAlign: 'baseline', position: 'relative',
        transition: 'background var(--dur-fast)',
      }}
      title={source}
    >
      {n}
      {hover && source && (
        <span style={{
          position: 'absolute', bottom: 'calc(100% + 4px)', left: '50%',
          transform: 'translateX(-50%)', background: 'var(--bg-overlay)',
          border: '1px solid var(--border-default)', borderRadius: 4,
          padding: '6px 8px', fontSize: 11, color: 'var(--fg-primary)',
          whiteSpace: 'nowrap', zIndex: 100, fontFamily: 'var(--font-sans)',
          boxShadow: 'var(--shadow-md)', pointerEvents: 'none',
        }}>{source}</span>
      )}
    </span>
  );
};

const Avatar = ({ name, size = 24, bg }) => {
  const initials = name.split(' ').map(s => s[0]).slice(0, 2).join('').toUpperCase();
  const palette = ['#3D4EFF', '#00C3E8', '#B27AE8', '#22C55E', '#F5B840', '#EF6C84'];
  const color = bg || palette[name.charCodeAt(0) % palette.length];
  return (
    <span style={{
      width: size, height: size, borderRadius: Math.max(3, size * 0.2),
      background: color, color: '#fff', display: 'inline-flex',
      alignItems: 'center', justifyContent: 'center', fontSize: size * 0.4,
      fontWeight: 600, flexShrink: 0, lineHeight: 1,
    }}>{initials}</span>
  );
};

const Logo = ({ size = 24 }) => (
  <svg viewBox="0 0 32 32" width={size} height={size}>
    <rect width="32" height="32" rx="7" fill="#3D4EFF"/>
    <rect x="8" y="18" width="3" height="7" fill="#E7EAF4"/>
    <rect x="13" y="12" width="3" height="13" fill="#E7EAF4"/>
    <rect x="18" y="15" width="3" height="10" fill="#E7EAF4"/>
    <path d="M8 10 L12 7 L16 9 L20 6 L24 8" stroke="#00C3E8" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="24" cy="8" r="1.8" fill="#00C3E8"/>
  </svg>
);

// Progress bar — thin, linear
const ProgressBar = ({ value = 0, tone = 'brand', style }) => {
  const toneColor = { brand: 'var(--brand-400)', ai: 'var(--accent-400)', success: 'var(--success)', neutral: 'var(--fg-secondary)' }[tone];
  return (
    <div style={{ height: 3, background: 'var(--bg-inset)', borderRadius: 2, overflow: 'hidden', ...style }}>
      <div style={{ width: `${Math.min(100, Math.max(0, value))}%`, height: '100%', background: toneColor, transition: 'width 220ms var(--ease-out)' }} />
    </div>
  );
};

// Horizontal divider with optional label
const Divider = ({ label, style }) => {
  if (!label) return <div style={{ height: 1, background: 'var(--border-subtle)', ...style }} />;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, ...style }}>
      <div style={{ flex: 1, height: 1, background: 'var(--border-subtle)' }} />
      <span style={{ fontSize: 10, color: 'var(--fg-tertiary)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{label}</span>
      <div style={{ flex: 1, height: 1, background: 'var(--border-subtle)' }} />
    </div>
  );
};

// Small inline "status dot" for nav items & counts
const StatusDot = ({ tone = 'neutral', size = 6 }) => {
  const color = {
    neutral: 'var(--fg-tertiary)',
    ai: 'var(--accent-400)',
    brand: 'var(--brand-400)',
    success: '#55C08C',
    warning: '#F5BF50',
    danger: '#F08080',
  }[tone];
  return <span style={{ width: size, height: size, background: color, borderRadius: '50%', flexShrink: 0, display: 'inline-block' }} />;
};

// Empty state placeholder
const EmptyState = ({ icon = 'sparkles', title, body, action, children }) => (
  <div style={{
    padding: '48px 24px', display: 'flex', flexDirection: 'column',
    alignItems: 'center', justifyContent: 'center', textAlign: 'center',
    color: 'var(--fg-tertiary)',
  }}>
    <div style={{
      width: 40, height: 40, borderRadius: 8,
      background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 14,
    }}>
      <Icon name={icon} size={18} color="var(--fg-tertiary)" />
    </div>
    <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--fg-primary)', marginBottom: 4 }}>{title}</div>
    {body && <div style={{ fontSize: 12, color: 'var(--fg-tertiary)', maxWidth: 320, lineHeight: 1.6 }}>{body}</div>}
    {(action || children) && <div style={{ marginTop: 16, display: 'flex', gap: 8 }}>{action || children}</div>}
  </div>
);

// Small "AI generated" marker — cyan dot + label
const AiMark = ({ label = 'AI', style }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 4,
    fontSize: 10, fontWeight: 500, color: 'var(--accent-400)',
    fontFamily: 'var(--font-sans)', letterSpacing: '0.06em', textTransform: 'uppercase',
    ...style,
  }}>
    <span style={{ width: 5, height: 5, background: 'var(--accent)', borderRadius: '50%' }} />
    {label}
  </span>
);

Object.assign(window, {
  Icon, useLucide, Button, IconButton, Badge, Kbd, Card, Label,
  CitationChip, Avatar, Logo, ProgressBar, Divider, StatusDot, EmptyState, AiMark,
});
