// DDReport.jsx — 企业尽调报告 surface
// Signature moments:
//  (1) 拖拽上传资料包 → AI 解析成结构化数据
//  (2) 两家标的公司并排对比 (AI 自动生成对比表)

const DD_SECTIONS = [
  { id: 'materials', label: '资料包',     icon: 'folder-open' },
  { id: 'profile',   label: '公司概况',   icon: 'building-2' },
  { id: 'financials',label: '财务分析',   icon: 'bar-chart-3' },
  { id: 'team',      label: '团队',       icon: 'users' },
  { id: 'compare',   label: '对标对比',   icon: 'columns-3' },
  { id: 'risks',     label: '风险点',     icon: 'alert-triangle' },
];

const DDReport = ({ onGoTo }) => {
  const [phase, setPhase] = useState('ready'); // 'empty' | 'uploading' | 'parsing' | 'ready'
  const [activeSection, setActiveSection] = useState('materials');
  useLucide(phase + activeSection);

  if (phase === 'empty') {
    return <DDEmpty onUpload={() => { setPhase('uploading'); setTimeout(() => setPhase('parsing'), 1500); setTimeout(() => setPhase('ready'), 4500); }} />;
  }

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: 'var(--bg-base)' }}>
      {/* Company header */}
      <div style={{
        padding: '14px 24px', borderBottom: '1px solid var(--border-subtle)',
        background: 'var(--bg-surface)', display: 'flex', alignItems: 'center', gap: 14,
      }}>
        <div style={{
          width: 40, height: 40, borderRadius: 6,
          background: 'linear-gradient(135deg, #3D4EFF, #5B6CFF)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontWeight: 600, fontSize: 15, flexShrink: 0,
        }}>LY</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <h1 style={{ fontSize: 16, fontWeight: 600, margin: 0, color: 'var(--fg-primary)' }}>凌云智算</h1>
            <span style={{ fontSize: 12, color: 'var(--fg-tertiary)', fontFamily: 'var(--font-mono)' }}>LingYun AI</span>
            <Badge tone="info" dot>尽调中</Badge>
            <Badge tone="subtle">B 轮 · ¥3.2亿</Badge>
          </div>
          <div style={{ fontSize: 11.5, color: 'var(--fg-tertiary)', marginTop: 3 }}>
            进度 62% · 11 份材料已解析 · 3 处待验证
          </div>
        </div>
        <Button size="sm" variant="ghost" leading="history">活动</Button>
        <Button size="sm" leading="share-2">协作</Button>
        <Button size="sm" variant="primary" leading="file-plus" onClick={() => onGoTo && onGoTo('memo')}>生成 IC 备忘录</Button>
      </div>

      {/* Progress strip */}
      <div style={{
        padding: '8px 24px', background: 'var(--bg-surface)',
        borderBottom: '1px solid var(--border-subtle)',
        display: 'flex', alignItems: 'center', gap: 12, fontSize: 11.5,
      }}>
        {[
          { label: '资料收集',    v: 100 },
          { label: '财务核验',    v: 82 },
          { label: '客户访谈',    v: 60 },
          { label: '法务尽调',    v: 40 },
          { label: '技术评估',    v: 45 },
          { label: 'IC 准备',     v: 10 },
        ].map((s, i, arr) => (
          <Fragment key={s.label}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap', flexShrink: 0 }}>
              <div style={{
                width: 18, height: 18, borderRadius: '50%',
                background: s.v === 100 ? 'var(--accent-muted)' : 'var(--bg-inset)',
                border: `1px solid ${s.v === 100 ? 'rgba(0,195,232,0.4)' : 'var(--border-default)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: s.v === 100 ? 'var(--accent-400)' : 'var(--fg-tertiary)',
                fontSize: 10, fontFamily: 'var(--font-numeric)', fontWeight: 500,
              }}>
                {s.v === 100 ? '✓' : (i + 1)}
              </div>
              <span style={{ color: s.v === 100 ? 'var(--fg-primary)' : 'var(--fg-secondary)' }}>{s.label}</span>
              <span style={{ color: 'var(--fg-tertiary)', fontFamily: 'var(--font-numeric)' }}>{s.v}%</span>
            </div>
            {i < arr.length - 1 && <div style={{ flex: 1, height: 1, background: 'var(--border-subtle)' }} />}
          </Fragment>
        ))}
      </div>

      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Section nav */}
        <div style={{
          width: 180, borderRight: '1px solid var(--border-subtle)',
          background: 'var(--bg-surface)', padding: '12px 8px', flexShrink: 0, overflow: 'auto',
        }}>
          <div style={{ fontSize: 10, color: 'var(--fg-tertiary)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 500, padding: '4px 10px 8px' }}>章节</div>
          {DD_SECTIONS.map(s => (
            <button key={s.id} onClick={() => setActiveSection(s.id)} style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 8,
              padding: '6px 10px', borderRadius: 4, border: 'none',
              background: activeSection === s.id ? 'var(--bg-active)' : 'transparent',
              color: activeSection === s.id ? 'var(--fg-primary)' : 'var(--fg-secondary)',
              fontSize: 12.5, cursor: 'pointer', fontFamily: 'var(--font-sans)',
              textAlign: 'left', fontWeight: activeSection === s.id ? 500 : 400,
            }}>
              <Icon name={s.icon} size={13} />
              {s.label}
            </button>
          ))}
        </div>

        <div style={{ flex: 1, overflow: 'auto', padding: '24px 32px 64px' }}>
          {activeSection === 'materials' && <DDMaterials phase={phase} onAdd={() => { setPhase('parsing'); setTimeout(() => setPhase('ready'), 3000); }} />}
          {activeSection === 'profile' && <DDProfile />}
          {activeSection === 'financials' && <DDFinancials />}
          {activeSection === 'team' && <DDTeam />}
          {activeSection === 'compare' && <DDCompare />}
          {activeSection === 'risks' && <DDRisks />}
        </div>
      </div>
    </div>
  );
};

const DDEmpty = ({ onUpload }) => (
  <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-base)' }}>
    <Card style={{ width: 540, padding: 32 }}>
      <AiMark label="新建尽调项目" />
      <h2 style={{ fontSize: 20, fontWeight: 600, color: 'var(--fg-primary)', margin: '12px 0 6px', letterSpacing: '-0.01em' }}>把资料拖进来,AI 帮你提取</h2>
      <div style={{ fontSize: 13, color: 'var(--fg-tertiary)', lineHeight: 1.65 }}>
        支持 BP / 财务 / 合同 / 访谈转写 / PDF / Excel / 录音。AI 会自动结构化,识别风险点,并同工商、财报数据交叉验证。
      </div>
      <div onClick={onUpload} style={{
        marginTop: 20, border: '1px dashed var(--border-strong)', borderRadius: 8,
        padding: 28, textAlign: 'center', cursor: 'pointer', background: 'var(--bg-inset)',
      }}>
        <Icon name="upload-cloud" size={32} color="var(--fg-tertiary)" />
        <div style={{ fontSize: 13, color: 'var(--fg-primary)', marginTop: 10, fontWeight: 500 }}>拖拽文件到此,或点击选择</div>
        <div style={{ fontSize: 11, color: 'var(--fg-tertiary)', marginTop: 4 }}>PDF · DOCX · XLSX · MP3 · TXT,最大 200 MB</div>
      </div>
    </Card>
  </div>
);

const DDMaterials = ({ phase, onAdd }) => (
  <div style={{ maxWidth: 940 }}>
    <SectionHeader title="资料包" subtitle="11 份材料 · AI 已完成解析与交叉验证" rightSlot={
      <div style={{ display: 'flex', gap: 6 }}>
        <Button size="xs" variant="ghost" leading="filter">类型</Button>
        <Button size="xs" leading="plus" onClick={onAdd}>添加</Button>
      </div>
    } />

    {/* Drop zone */}
    <Card style={{ padding: 0, marginBottom: 16, overflow: 'hidden', borderStyle: 'dashed' }}>
      <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          width: 32, height: 32, borderRadius: 6,
          background: phase === 'parsing' ? 'var(--accent-muted)' : 'var(--bg-inset)',
          border: `1px solid ${phase === 'parsing' ? 'rgba(0,195,232,0.3)' : 'var(--border-subtle)'}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name={phase === 'parsing' ? 'loader-circle' : 'upload-cloud'} size={16}
            color={phase === 'parsing' ? 'var(--accent-400)' : 'var(--fg-secondary)'}
            style={phase === 'parsing' ? { animation: 'spin 1s linear infinite' } : {}}
          />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, color: 'var(--fg-primary)', fontWeight: 500 }}>
            {phase === 'parsing' ? 'AI 正在解析 3 份新材料...' : '拖拽文件到此或点击添加'}
          </div>
          <div style={{ fontSize: 11, color: 'var(--fg-tertiary)', marginTop: 2 }}>
            {phase === 'parsing' ? '识别结构 · 提取 KPI · 交叉验证 · 预计还需 18 秒' : '支持 PDF / DOCX / XLSX / MP3 / TXT · 单文件最大 200 MB'}
          </div>
        </div>
        {phase === 'parsing' && <ProgressBar value={62} tone="ai" style={{ width: 120 }} />}
      </div>
    </Card>

    {/* Materials list */}
    <Card style={{ overflow: 'hidden' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5 }}>
        <thead>
          <tr style={{ background: 'var(--bg-surface)', borderBottom: '1px solid var(--border-default)' }}>
            {['文件', '类型', '页数 / 时长', 'AI 提取', '交叉验证', '上传', ''].map(h => (
              <th key={h} style={{ textAlign: 'left', padding: '8px 12px', fontSize: 10.5, color: 'var(--fg-tertiary)', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {[
            { name: '凌云智算_BP_v4.pdf',          type: 'BP',    size: '48 页',     ext: 142, vr: 'ok',    date: '4-08' },
            { name: '凌云智算_Q1财务_2026.xlsx',  type: '财务',  size: '6 sheets',  ext: 86,  vr: 'warn',  date: '4-10' },
            { name: '创始人访谈_录音转写.txt',    type: '访谈',  size: '86 分钟',  ext: 24,  vr: 'ok',    date: '4-12' },
            { name: '客户访谈_智谱 AI_纪要.pdf',  type: '访谈',  size: '8 页',      ext: 18,  vr: 'ok',    date: '4-15' },
            { name: '客户访谈_月之暗面_纪要.pdf', type: '访谈',  size: '12 页',     ext: 22,  vr: 'ok',    date: '4-16' },
            { name: '长三角算力中心_租约.pdf',    type: '合同',  size: '24 页',     ext: 14,  vr: 'warn',  date: '4-17' },
            { name: '设备采购清单_2025.xlsx',     type: '财务',  size: '3 sheets',  ext: 42,  vr: 'ok',    date: '4-17' },
            { name: '工商档案_启信宝.pdf',        type: '公开',  size: '16 页',     ext: 38,  vr: 'ok',    date: '4-18' },
            { name: '技术白皮书_v2.pdf',          type: '技术',  size: '32 页',     ext: 56,  vr: 'ok',    date: '4-20' },
            { name: '股东协议_SPA_draft.pdf',    type: '法务',  size: '42 页',     ext: 31,  vr: 'pending', date: '4-21' },
            { name: '审计报告_2024_德勤.pdf',    type: '财务',  size: '86 页',     ext: 124, vr: 'ok',    date: '4-21' },
          ].map((m, i) => (
            <tr key={i} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
              <td style={{ padding: '9px 12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <Icon name={m.type === '财务' ? 'file-spreadsheet' : m.type === '访谈' ? 'mic' : 'file-text'} size={13} color="var(--fg-secondary)" />
                  <span style={{ color: 'var(--fg-primary)', fontFamily: 'var(--font-mono)', fontSize: 12 }}>{m.name}</span>
                </div>
              </td>
              <td style={{ padding: '9px 12px' }}><Badge>{m.type}</Badge></td>
              <td style={{ padding: '9px 12px', color: 'var(--fg-secondary)' }}>{m.size}</td>
              <td style={{ padding: '9px 12px' }}>
                <span style={{ fontFamily: 'var(--font-numeric)', color: 'var(--accent-400)' }}>{m.ext}</span>
                <span style={{ fontSize: 10.5, color: 'var(--fg-tertiary)', marginLeft: 3 }}>条字段</span>
              </td>
              <td style={{ padding: '9px 12px' }}>
                {m.vr === 'ok' && <Badge tone="success" dot>通过</Badge>}
                {m.vr === 'warn' && <Badge tone="warning" dot>待核对</Badge>}
                {m.vr === 'pending' && <Badge tone="subtle" dot>处理中</Badge>}
              </td>
              <td style={{ padding: '9px 12px', color: 'var(--fg-tertiary)', fontFamily: 'var(--font-numeric)', fontSize: 11.5 }}>{m.date}</td>
              <td style={{ padding: '9px 12px', textAlign: 'right' }}>
                <IconButton icon="more-horizontal" size={22} iconSize={13} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Card>

    {/* AI findings */}
    <div style={{ marginTop: 16 }}>
      <SectionHeader title="AI 发现的问题" ai subtitle="基于 11 份材料与工商、财报数据的交叉验证" />
      {[
        { tone: 'warning', title: '营收口径差异',  body: 'BP 中 2025 年营收 ¥4.5 亿,财务 sheet 为 ¥4.2 亿,差异 ¥3000 万来自是否包含代运营收入。',    sources: ['凌云智算_BP_v4.pdf p.18', '凌云智算_Q1财务_2026.xlsx'] },
        { tone: 'warning', title: '电价政策依赖',  body: '长三角算力中心租约中,电价补贴 0.08 元/度 协议至 2027-12,后续续约条款未约定。',                  sources: ['长三角算力中心_租约.pdf p.19'] },
        { tone: 'info',    title: '客户集中度',    body: '前 3 大客户 (智谱 / 月之暗面 / MiniMax) 合计占营收 72%。最大客户智谱占 38%。',                     sources: ['凌云智算_Q1财务_2026.xlsx', '客户访谈_智谱 AI_纪要.pdf'] },
      ].map((f, i) => (
        <Card key={i} style={{ padding: 14, marginBottom: 10, borderLeft: `2px solid ${f.tone === 'warning' ? 'var(--warning)' : 'var(--brand-400)'}` }}>
          <div style={{ display: 'flex', gap: 10 }}>
            <Icon name={f.tone === 'warning' ? 'alert-triangle' : 'info'} size={14} color={f.tone === 'warning' ? 'var(--warning)' : 'var(--brand-400)'} style={{ marginTop: 3, flexShrink: 0 }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--fg-primary)' }}>{f.title}</div>
              <div style={{ fontSize: 12.5, color: 'var(--fg-secondary)', lineHeight: 1.65, marginTop: 4 }}>{f.body}</div>
              <div style={{ display: 'flex', gap: 4, marginTop: 8, flexWrap: 'wrap' }}>
                {f.sources.map((s, si) => (
                  <span key={si} style={{
                    fontSize: 10.5, color: 'var(--fg-secondary)', fontFamily: 'var(--font-mono)',
                    background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)',
                    borderRadius: 3, padding: '1px 6px',
                  }}>{s}</span>
                ))}
              </div>
            </div>
            <Button size="xs" variant="ghost">追问</Button>
          </div>
        </Card>
      ))}
    </div>
  </div>
);

const DDProfile = () => (
  <div style={{ maxWidth: 820 }}>
    <SectionHeader title="公司概况" subtitle="AI 根据上传资料与工商数据自动填充" ai />
    <Card style={{ padding: 20 }}>
      <div style={{ fontSize: 14, color: 'var(--fg-primary)', lineHeight: 1.7 }}>
        {TARGET.description}<CitationChip n="1" source="凌云智算_BP_v4.pdf p.4" />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginTop: 20, borderTop: '1px solid var(--border-subtle)', paddingTop: 16 }}>
        {[
          ['成立日期', TARGET.founded],
          ['总部',    TARGET.hq],
          ['员工',    `${TARGET.employees} 人`],
          ['阶段',    TARGET.stage],
          ['本轮融资', TARGET.ask],
          ['Pre-money', TARGET.valuation],
          ['认购比例', TARGET.ownership],
          ['董事席位', '观察员'],
        ].map(([l, v], i) => (
          <div key={i}>
            <Label>{l}</Label>
            <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--fg-primary)', marginTop: 4, fontVariantNumeric: 'tabular-nums' }}>{v}</div>
          </div>
        ))}
      </div>
    </Card>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginTop: 16 }}>
      {TARGET.kpis.map((k, i) => (
        <Card key={i} style={{ padding: 14 }}>
          <Label>{k.label}</Label>
          <div style={{ fontSize: 22, fontWeight: 600, color: 'var(--fg-primary)', margin: '6px 0 2px', fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.01em' }}>
            {k.value}
            <span style={{ fontSize: 11, color: 'var(--fg-tertiary)', marginLeft: 4, fontWeight: 400 }}>{k.unit}</span>
          </div>
          <div style={{ fontSize: 11, color: k.deltaType === 'up' ? 'var(--success)' : k.deltaType === 'warning' ? 'var(--warning)' : 'var(--fg-tertiary)', fontFamily: 'var(--font-numeric)' }}>{k.delta}</div>
        </Card>
      ))}
    </div>
  </div>
);

const DDFinancials = () => (
  <div style={{ maxWidth: 820 }}>
    <SectionHeader title="财务分析" subtitle="近 3 年 · AI 从审计报告与财务表汇总" ai />
    <Card style={{ overflow: 'hidden' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5 }}>
        <thead>
          <tr style={{ background: 'var(--bg-surface)', borderBottom: '1px solid var(--border-default)' }}>
            <th style={{ textAlign: 'left', padding: '8px 14px', fontSize: 10.5, color: 'var(--fg-tertiary)', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.06em' }}>指标</th>
            {['2023', '2024', '2025', '2026E'].map(y => (
              <th key={y} style={{ textAlign: 'right', padding: '8px 14px', fontSize: 10.5, color: 'var(--fg-tertiary)', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{y}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {[
            ['营收 (¥亿)',      '0.4',  '1.0',  '4.2',  '9.8'],
            ['毛利 (¥亿)',      '0.08', '0.26', '1.62', '3.92'],
            ['毛利率',          '20.0%','26.0%','38.6%','40.0%'],
            ['经营现金流 (¥亿)', '-0.8', '-0.6', '0.9',  '2.4'],
            ['GPU 卡量 (张)',   '2,400','6,800','12,800','22,500'],
            ['单卡利用率',      '56%',  '62%',  '68%',  '72%'],
            ['客户数',          '4',    '9',    '14',   '22'],
          ].map((r, i) => (
            <tr key={i} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
              <td style={{ padding: '9px 14px', color: 'var(--fg-primary)', fontWeight: 500 }}>{r[0]}</td>
              {r.slice(1).map((v, vi) => (
                <td key={vi} style={{ padding: '9px 14px', textAlign: 'right', color: 'var(--fg-primary)', fontFamily: 'var(--font-numeric)', fontVariantNumeric: 'tabular-nums', opacity: vi === 3 ? 0.65 : 1 }}>{v}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </Card>
    <div style={{ marginTop: 12, fontSize: 11.5, color: 'var(--fg-tertiary)' }}>
      2026E 为 AI 基于已签约 ARR (¥7.8亿) + 管线转化率测算,口径与审计报告一致<CitationChip n="1" source="审计报告_2024_德勤.pdf" /><CitationChip n="2" source="凌云智算_Q1财务_2026.xlsx" />。
    </div>
  </div>
);

const DDTeam = () => (
  <div style={{ maxWidth: 820 }}>
    <SectionHeader title="团队" subtitle="核心管理层 · AI 从 BP、工商档案与访谈提取" />
    {[
      { name: '张云峰', title: 'CEO & 创始人', bg: '前阿里云智能副总裁,负责弹性计算 GPU 产品线 12 年;上交大计算机博士。', tag: 'core' },
      { name: '李明哲', title: 'CTO',         bg: '前华为 2012 实验室 AI 芯片架构师;参与昇腾 910 / 910B 设计。',          tag: 'core' },
      { name: '王洁',   title: 'CFO',         bg: '前普华永道 TMT 组合伙人;8 年科技公司上市辅导经验。',                   tag: '' },
      { name: '刘星',   title: 'COO',         bg: '前世纪互联高级副总裁,数据中心规划与运营 15 年经验。',                  tag: '' },
    ].map((p, i) => (
      <Card key={i} style={{ padding: 14, marginBottom: 10, display: 'flex', gap: 14, alignItems: 'flex-start' }}>
        <Avatar name={p.name} size={40} />
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 14, fontWeight: 500, color: 'var(--fg-primary)' }}>{p.name}</span>
            <span style={{ fontSize: 12, color: 'var(--fg-secondary)' }}>· {p.title}</span>
            {p.tag === 'core' && <Badge tone="info">核心</Badge>}
          </div>
          <div style={{ fontSize: 12.5, color: 'var(--fg-secondary)', marginTop: 6, lineHeight: 1.65 }}>{p.bg}</div>
        </div>
      </Card>
    ))}
  </div>
);

const DDCompare = () => (
  <div style={{ maxWidth: 980 }}>
    <SectionHeader title="对标对比" subtitle="凌云智算 vs 秦淮数据" ai
      rightSlot={<Button size="xs" leading="plus">添加对标</Button>}
    />
    <Card style={{ overflow: 'hidden' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5 }}>
        <thead>
          <tr style={{ background: 'var(--bg-surface)', borderBottom: '1px solid var(--border-default)' }}>
            <th style={{ textAlign: 'left', padding: '10px 14px', fontSize: 10.5, color: 'var(--fg-tertiary)', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.06em' }}>指标</th>
            {COMPARE_TARGETS.map(t => (
              <th key={t.id} style={{ textAlign: 'left', padding: '10px 14px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 24, height: 24, borderRadius: 4, background: t.id === 'lingyun' ? 'var(--brand-500)' : 'var(--bg-inset)', border: t.id === 'lingyun' ? 'none' : '1px solid var(--border-default)', color: t.id === 'lingyun' ? '#fff' : 'var(--fg-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 600 }}>{t.name.charAt(0)}</div>
                  <div>
                    <div style={{ fontSize: 13, color: 'var(--fg-primary)', fontWeight: 500 }}>{t.name}</div>
                    <div style={{ fontSize: 10.5, color: 'var(--fg-tertiary)', fontFamily: 'var(--font-mono)' }}>{t.eng} · {t.status}</div>
                  </div>
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {Object.keys(COMPARE_TARGETS[0].metrics).map((k, i) => {
            const lyWin = COMPARE_TARGETS[0].metrics[k].w === 'LY';
            const cdWin = COMPARE_TARGETS[1].metrics[k].w === 'CD';
            return (
              <tr key={k} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                <td style={{ padding: '10px 14px', color: 'var(--fg-secondary)' }}>{k}</td>
                {COMPARE_TARGETS.map((t, ti) => {
                  const m = t.metrics[k];
                  const win = (ti === 0 && lyWin) || (ti === 1 && cdWin);
                  return (
                    <td key={t.id} style={{ padding: '10px 14px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{
                          color: m.warn ? 'var(--warning)' : win ? 'var(--fg-primary)' : 'var(--fg-primary)',
                          fontWeight: win ? 600 : 400,
                          fontFamily: 'var(--font-numeric)', fontVariantNumeric: 'tabular-nums',
                        }}>{m.v}</span>
                        {win && <Icon name="chevron-up" size={12} color="var(--success)" />}
                        {m.warn && <Icon name="alert-triangle" size={11} color="var(--warning)" />}
                      </div>
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </Card>
    <Card style={{ padding: 14, marginTop: 16 }}>
      <AiMark label="AI 小结" />
      <div style={{ fontSize: 13, color: 'var(--fg-primary)', lineHeight: 1.75, marginTop: 6 }}>
        凌云智算相对秦淮数据:(1) 规模小 31%,但增速领先 227pp;(2) 估值 2.3× ARR 低于秦淮 3.8× ARR,具备上行空间;(3) 劣势在国产化率 (34% vs 42%) 和客户集中度 (72% vs 58%),需要在投后协助补齐<CitationChip n="1" source="秦淮数据 2025 年报" /><CitationChip n="2" source="凌云智算_Q1财务_2026.xlsx" />。
      </div>
    </Card>
  </div>
);

const DDRisks = () => (
  <div style={{ maxWidth: 820 }}>
    <SectionHeader title="风险点" subtitle="AI 综合评估 · 4 高 · 3 中" />
    {[
      { level: 'high',   title: '客户集中度', body: '前 3 大客户占营收 72%,其中智谱 AI 单家 38%。若任一客户训练节奏放缓,季度营收波动可能超过 25%。' },
      { level: 'high',   title: '电价政策依赖', body: '核心机房电价优势 (0.38 元/度) 依赖地方补贴,协议到 2027-12 截止,续约条款未定。' },
      { level: 'medium', title: '国产化率',   body: '国产化率 34% 低于行业头部 (秦淮 42%, 曙光 58%)。若美方加码出口管制,短期扩张节奏可能受阻。' },
      { level: 'medium', title: '估值合理性', body: '2.3× ARR 估值相对行业可比偏低,但若 2026 年营收未达 ¥8 亿,则估值倍数会向 3.0× 回归。' },
    ].map((r, i) => {
      const tone = r.level === 'high' ? 'danger' : 'warning';
      const color = r.level === 'high' ? 'var(--danger)' : 'var(--warning)';
      return (
        <Card key={i} style={{ padding: 14, marginBottom: 10, borderLeft: `2px solid ${color}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Badge tone={tone}>{r.level === 'high' ? '高' : '中'}</Badge>
            <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--fg-primary)' }}>{r.title}</span>
          </div>
          <div style={{ fontSize: 12.5, color: 'var(--fg-secondary)', lineHeight: 1.65 }}>{r.body}</div>
        </Card>
      );
    })}
  </div>
);

window.DDReport = DDReport;
