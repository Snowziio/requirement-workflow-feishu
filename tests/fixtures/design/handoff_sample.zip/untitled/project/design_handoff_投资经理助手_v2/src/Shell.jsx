// Shell.jsx — NavRail + Sidebar + Topbar
const SHELL_NAV = [
  { id: 'dashboard', icon: 'layout-dashboard', label: '工作台' },
  { id: 'research',  icon: 'telescope',        label: '行业调研' },
  { id: 'dd',        icon: 'clipboard-check',  label: '尽调报告' },
  { id: 'memo',      icon: 'file-signature',   label: '投委会备忘录' },
  { id: 'screener',  icon: 'scan-search',      label: '项目筛选' },
  { id: 'portfolio', icon: 'briefcase',        label: '投后组合' },
  { id: 'library',   icon: 'library',          label: '资料库' },
];

const NavRail = ({ active, onNavigate }) => {
  return (
    <div style={{
      width: 52, background: 'var(--bg-surface)',
      borderRight: '1px solid var(--border-subtle)',
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      padding: '10px 0', gap: 2, flexShrink: 0,
    }}>
      <div style={{ padding: '2px 0 10px' }}><Logo size={26} /></div>
      <div style={{ width: 28, height: 1, background: 'var(--border-subtle)', margin: '2px 0 6px' }} />
      {SHELL_NAV.map(item => (
        <IconButton
          key={item.id}
          icon={item.icon}
          size={34}
          iconSize={17}
          active={active === item.id}
          onClick={() => onNavigate(item.id)}
          title={item.label}
        />
      ))}
      <div style={{ flex: 1 }} />
      <IconButton icon="help-circle" size={34} iconSize={16} />
      <IconButton icon="settings" size={34} iconSize={16} />
      <div style={{ margin: '4px 0 2px' }}><Avatar name="Jin Li" size={28} bg="#3D4EFF" /></div>
    </div>
  );
};

// Secondary sidebar — context-aware. Different content per surface.
const Sidebar = ({ surface, onSelectDeal, activeDealId, onCreate }) => {
  const title = {
    dashboard: '工作台',
    research: '行业调研',
    dd: '尽调项目',
    memo: '备忘录',
    screener: '项目筛选',
    portfolio: '投后组合',
    library: '资料库',
  }[surface] || '';

  const ResearchSidebar = () => (
    <>
      <SidebarSection label="进行中">
        <SidebarItem icon="telescope" title="AI 基础设施 · 智算中心" meta="凌云智算相关" active updated="今天 11:42" />
        <SidebarItem icon="telescope" title="国产 AI 芯片替代" meta="寒武纪 / 海光" updated="昨天" />
      </SidebarSection>
      <SidebarSection label="已归档">
        <SidebarItem icon="folder" title="新能源汽车动力电池" meta="2026 Q1" />
        <SidebarItem icon="folder" title="创新药 CXO 赛道" meta="2025 Q4" />
        <SidebarItem icon="folder" title="半导体设备国产替代" meta="2025 Q4" />
        <SidebarItem icon="folder" title="SaaS 企业服务" meta="2025 Q3" />
      </SidebarSection>
    </>
  );

  const DDSidebar = () => (
    <>
      <SidebarSection label="活跃项目" count={3}>
        {PIPELINE.filter(d => d.stage === '尽调中' || d.stage === 'IC 审议').map(d => (
          <SidebarDealItem key={d.id} deal={d} active={d.id === activeDealId} onClick={() => onSelectDeal && onSelectDeal(d.id)} />
        ))}
      </SidebarSection>
      <SidebarSection label="早期接触">
        {PIPELINE.filter(d => d.stage === '初步接触').map(d => (
          <SidebarDealItem key={d.id} deal={d} active={d.id === activeDealId} onClick={() => onSelectDeal && onSelectDeal(d.id)} />
        ))}
      </SidebarSection>
      <SidebarSection label="已归档">
        {PIPELINE.filter(d => d.stage === '已投' || d.stage === '已 Pass').map(d => (
          <SidebarDealItem key={d.id} deal={d} active={d.id === activeDealId} onClick={() => onSelectDeal && onSelectDeal(d.id)} />
        ))}
      </SidebarSection>
    </>
  );

  const MemoSidebar = () => (
    <>
      <SidebarSection label="进行中">
        <SidebarItem icon="file-signature" title="凌云智算 — B 轮投委会" meta="草稿 · 8 章节" active updated="10 分钟前" />
        <SidebarItem icon="file-signature" title="墨芯科技 — B+ 追投" meta="已提交 IC" updated="昨天" />
      </SidebarSection>
      <SidebarSection label="历史">
        <SidebarItem icon="file-check-2" title="智谱 AI — D 轮" meta="已批准" />
        <SidebarItem icon="file-check-2" title="月之暗面 — B 轮" meta="已批准" />
        <SidebarItem icon="file-x" title="阶跃星辰 — B 轮" meta="Pass" />
      </SidebarSection>
    </>
  );

  const DefaultSidebar = () => (
    <>
      <SidebarSection label="快捷">
        <SidebarItem icon="star" title="关注列表" meta="12 家公司" />
        <SidebarItem icon="clock" title="最近打开" meta="" />
      </SidebarSection>
      <SidebarSection label="工作流">
        <SidebarItem icon="telescope" title="行业调研" meta="2 个进行中" />
        <SidebarItem icon="clipboard-check" title="尽调报告" meta="3 个进行中" />
        <SidebarItem icon="file-signature" title="投委会备忘录" meta="2 个草稿" />
      </SidebarSection>
    </>
  );

  return (
    <div style={{
      width: 248, background: 'var(--bg-surface)',
      borderRight: '1px solid var(--border-subtle)',
      display: 'flex', flexDirection: 'column', flexShrink: 0,
      overflow: 'hidden',
    }}>
      <div style={{
        padding: '10px 12px 8px', display: 'flex', alignItems: 'center', gap: 8,
      }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--fg-primary)', letterSpacing: 0 }}>{title}</div>
        <div style={{ flex: 1 }} />
        {(surface === 'research' || surface === 'dd' || surface === 'memo') && (
          <IconButton icon="plus" size={22} iconSize={14} onClick={onCreate} title="新建" />
        )}
      </div>
      <div style={{
        margin: '0 10px 8px', height: 28, background: 'var(--bg-inset)',
        border: '1px solid var(--border-subtle)', borderRadius: 4,
        display: 'flex', alignItems: 'center', padding: '0 8px', gap: 6,
      }}>
        <Icon name="search" size={12} color="var(--fg-tertiary)" />
        <input placeholder="过滤..." style={{
          flex: 1, background: 'transparent', border: 'none', outline: 'none',
          color: 'var(--fg-primary)', fontSize: 12, fontFamily: 'var(--font-sans)',
        }} />
      </div>
      <div style={{ flex: 1, overflow: 'auto', paddingBottom: 12 }}>
        {surface === 'research' && <ResearchSidebar />}
        {surface === 'dd' && <DDSidebar />}
        {surface === 'memo' && <MemoSidebar />}
        {!['research','dd','memo'].includes(surface) && <DefaultSidebar />}
      </div>
    </div>
  );
};

const SidebarSection = ({ label, count, children }) => (
  <div style={{ marginTop: 12, marginBottom: 4 }}>
    <div style={{
      padding: '4px 14px', display: 'flex', alignItems: 'center', gap: 6,
      fontSize: 10, color: 'var(--fg-tertiary)', textTransform: 'uppercase',
      letterSpacing: '0.08em', fontWeight: 500,
    }}>
      <span>{label}</span>
      {count !== undefined && (
        <span style={{
          background: 'var(--bg-inset)', color: 'var(--fg-tertiary)',
          borderRadius: 9999, padding: '1px 6px', fontSize: 10, letterSpacing: 0,
        }}>{count}</span>
      )}
    </div>
    <div style={{ display: 'flex', flexDirection: 'column' }}>{children}</div>
  </div>
);

const SidebarItem = ({ icon, title, meta, active, updated, onClick }) => {
  const [hover, setHover] = useState(false);
  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onClick={onClick}
      style={{
        margin: '0 6px', padding: '6px 10px', borderRadius: 4,
        background: active ? 'var(--bg-active)' : (hover ? 'var(--bg-hover)' : 'transparent'),
        cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8,
        borderLeft: active ? '2px solid var(--brand-400)' : '2px solid transparent',
        paddingLeft: active ? 8 : 10,
      }}
    >
      <Icon name={icon} size={13} color={active ? 'var(--fg-primary)' : 'var(--fg-tertiary)'} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 12.5,
          color: active ? 'var(--fg-primary)' : (hover ? 'var(--fg-primary)' : 'var(--fg-secondary)'),
          fontWeight: active ? 500 : 400, whiteSpace: 'nowrap', overflow: 'hidden',
          textOverflow: 'ellipsis',
          transition: 'color 120ms ease',
        }}>{title}</div>
        {meta && <div style={{ fontSize: 10.5, color: 'var(--fg-tertiary)', marginTop: 1 }}>{meta}</div>}
      </div>
      {updated && <div style={{ fontSize: 10, color: 'var(--fg-tertiary)', flexShrink: 0 }}>{updated}</div>}
    </div>
  );
};

const SidebarDealItem = ({ deal, active, onClick }) => {
  const [hover, setHover] = useState(false);
  const statusTone = {
    hot: 'warning', active: 'info', cold: 'subtle',
    invested: 'success', pass: 'subtle',
  }[deal.status];
  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onClick={onClick}
      style={{
        margin: '0 6px', padding: '7px 10px', borderRadius: 4,
        background: active ? 'var(--bg-active)' : (hover ? 'var(--bg-hover)' : 'transparent'),
        cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 9,
        borderLeft: active ? '2px solid var(--brand-400)' : '2px solid transparent',
        paddingLeft: active ? 8 : 10,
      }}
    >
      <div style={{
        width: 22, height: 22, borderRadius: 4,
        background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 10, fontWeight: 600, color: 'var(--fg-secondary)', flexShrink: 0,
      }}>{deal.name.charAt(0)}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 12.5, color: 'var(--fg-primary)',
          fontWeight: active ? 500 : 400, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>{deal.name}</div>
        <div style={{ fontSize: 10.5, color: 'var(--fg-tertiary)', marginTop: 1 }}>
          {deal.round} · {deal.size}
        </div>
      </div>
      <StatusDot tone={statusTone} />
    </div>
  );
};

const Topbar = ({ theme, onToggleTheme, breadcrumb, aiOpen, onToggleAi, onOpenCmd }) => (
  <div style={{
    height: 44, background: 'var(--bg-surface)',
    borderBottom: '1px solid var(--border-subtle)',
    display: 'flex', alignItems: 'center', padding: '0 12px', gap: 10, flexShrink: 0,
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, flex: '0 0 auto', minWidth: 0, whiteSpace: 'nowrap', flexShrink: 0 }}>
      {breadcrumb.map((b, i) => (
        <Fragment key={i}>
          {i > 0 && <Icon name="chevron-right" size={12} color="var(--fg-tertiary)" style={{ flexShrink: 0 }} />}
          <span style={{
            fontSize: 12.5,
            color: i === breadcrumb.length - 1 ? 'var(--fg-primary)' : 'var(--fg-secondary)',
            fontWeight: i === breadcrumb.length - 1 ? 500 : 400,
            whiteSpace: 'nowrap',
            flexShrink: 0,
          }}>{b}</span>
        </Fragment>
      ))}
    </div>
    <div style={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
      <button onClick={onOpenCmd} style={{
        width: 420, maxWidth: '100%', height: 28,
        background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)',
        borderRadius: 4, display: 'flex', alignItems: 'center', padding: '0 10px', gap: 8,
        cursor: 'pointer', fontFamily: 'var(--font-sans)',
      }}>
        <Icon name="search" size={13} color="var(--fg-tertiary)" />
        <span style={{ flex: 1, fontSize: 12, color: 'var(--fg-tertiary)', textAlign: 'left' }}>
          搜索公司、项目、备忘录,或直接提问…
        </span>
        <Kbd>⌘K</Kbd>
      </button>
    </div>
    <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
      <IconButton icon={theme === 'dark' ? 'moon' : 'sun'} title="主题" onClick={onToggleTheme} />
      <IconButton icon="bell" title="通知" />
      <div style={{ width: 1, height: 18, background: 'var(--border-default)', margin: '0 6px' }} />
      <IconButton
        icon="sparkles"
        title="AI Copilot"
        onClick={onToggleAi}
        active={aiOpen}
        tone={aiOpen ? 'neutral' : 'ai'}
      />
    </div>
  </div>
);

Object.assign(window, { NavRail, Sidebar, SidebarItem, SidebarSection, SidebarDealItem, Topbar });
