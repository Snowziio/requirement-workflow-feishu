// Memo.jsx — 投委会备忘录 surface
// Signature moment: streaming long-form generation with live citation chips

const MEMO_SECTIONS = [
  { id: 'summary',    label: '执行摘要' },
  { id: 'thesis',     label: '投资逻辑' },
  { id: 'market',     label: '市场' },
  { id: 'team',       label: '团队' },
  { id: 'financials', label: '财务' },
  { id: 'risks',      label: '风险' },
  { id: 'valuation',  label: '估值' },
  { id: 'recommend',  label: '建议' },
];

// Each paragraph: { section, title?, text, citations: [{pos, n, source}] }
const MEMO_CONTENT = [
  { section: 'summary', heading: 'h1', text: '凌云智算 — B 轮投资建议书', role: 'title' },
  { section: 'summary', heading: 'meta', text: '拟投资额 ¥3.2 亿 · Pre-money ¥18 亿 · 认购 17.8%  ·  准备人:金立  ·  IC 日期:2026-04-28' },
  { section: 'summary', heading: 'kpis' }, // special row
  { section: 'summary', heading: 'h2', text: '执行摘要' },
  { section: 'summary', text: '我们建议领投凌云智算 B 轮 ¥3.2 亿融资,pre-money 估值 ¥18 亿,本轮 fund 认购比例 17.8%。凌云智算是中国头部独立智算中心运营商,已部署 12,800 张 GPU,2025 年营收 ¥4.2 亿,同比增长 312%。', citations: [[126, '1', '凌云智算_Q1财务_2026.xlsx'], [146, '2', '凌云智算_BP_v4.pdf p.6']] },
  { section: 'summary', text: '核心吸引力在于:(1) 创始人张云峰的阿里云背景带来稀缺的 GPU 集群运营经验;(2) 已绑定智谱、月之暗面、MiniMax 三家头部大模型厂商,签约合同 ARR 达 ¥7.8 亿;(3) 长三角电价优势 0.38 元/度 支撑 38.6% 毛利率,显著高于行业平均。', citations: [[68, '3', '创始人访谈_录音转写.txt'], [128, '4', '客户访谈_智谱 AI_纪要.pdf'], [184, '5', '长三角算力中心_租约.pdf']] },

  { section: 'thesis', heading: 'h2', text: '投资逻辑' },
  { section: 'thesis', text: '智算中心是 AI 时代最底层、最具确定性的基础设施。我们认为凌云智算处在产业链最具投资价值的节点:向上承接国产 AI 芯片(昇腾 910B)替代机遇,向下绑定头部大模型厂商的训练刚需,中间建立了电价 + 运维的双重护城河。', citations: [[80, '6', '中信证券 · 国产 AI 芯片深度']] },
  { section: 'thesis', text: '过去 18 个月行业发生两个结构性变化:训练算力从"H100 供给不足"转向"国产芯片可用",智算中心从"云厂商副业"转向"独立运营商主导"。凌云是第一批完成这两次切换的公司,先发优势正在变现。', citations: [[74, '7', '专家访谈 · 某云厂商采购负责人']] },

  { section: 'market', heading: 'h2', text: '市场' },
  { section: 'market', text: '2025 年国内智算中心市场规模 ¥2480 亿,同比 +79%;2028 年预计 ¥7280 亿,CAGR 43%。中游独立运营商市场份额从 2023 年 22% 上升至 2025 年 38%,挤占云厂商存量。', citations: [[36, '8', 'Wind · AI 芯片板块'], [118, '9', '中信证券 · 行业深度']] },

  { section: 'risks', heading: 'h2', text: '风险' },
  { section: 'risks', text: '需在 TS 中约定的缓释条款:(1) 客户集中度:前 3 客户占 72%。建议设置分阶段支付,对应 2026 H1 签约客户数达 5 家。(2) 电价依赖:补贴到 2027 年底。要求管理层提供续约可能性评估并在 2027 Q1 前落实替代方案。(3) 国产化率 34%:低于行业头部,但考虑到昇腾供货改善,预计 2026 年底可提升至 45%+。', citations: [[82, '10', '凌云智算_Q1财务_2026.xlsx'], [166, '11', '长三角算力中心_租约.pdf']] },

  { section: 'recommend', heading: 'h2', text: '建议' },
  { section: 'recommend', text: '建议 IC 批准本次领投。我们认为这是一个在中国 AI 基础设施浪潮中具备稀缺性 + 可验证成长 + 合理估值的交易。按现有 ARR 与行业 3.0× 平均水平保守测算,3 年回报预计 2.8-3.5× MOIC,IRR 区间 38-46%。', citations: [[28, '12', '财务敏感性 · AI 生成']] },
];

const Memo = ({ onGoTo }) => {
  const [phase, setPhase] = useState('final'); // 'empty' | 'streaming' | 'final'
  const [active, setActive] = useState('summary');
  const [visibleChars, setVisibleChars] = useState({});
  const streamIntervalRef = useRef(null);
  useLucide(phase + active);

  const startStream = () => {
    setPhase('streaming');
    setVisibleChars({});
    const paragraphs = MEMO_CONTENT.filter(p => p.text && !p.heading);
    let pIdx = 0;
    let cIdx = 0;
    clearInterval(streamIntervalRef.current);
    streamIntervalRef.current = setInterval(() => {
      if (pIdx >= paragraphs.length) {
        clearInterval(streamIntervalRef.current);
        setPhase('final');
        return;
      }
      const p = paragraphs[pIdx];
      cIdx += Math.max(3, Math.floor(p.text.length / 40));
      setVisibleChars(v => ({ ...v, [pIdx]: Math.min(p.text.length, cIdx) }));
      if (cIdx >= p.text.length) { pIdx++; cIdx = 0; }
    }, 45);
  };

  useEffect(() => () => clearInterval(streamIntervalRef.current), []);

  if (phase === 'empty') return <MemoEmpty onStart={startStream} />;

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: 'var(--bg-base)' }}>
      <div style={{
        padding: '10px 24px', borderBottom: '1px solid var(--border-subtle)',
        background: 'var(--bg-surface)', display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <Icon name="file-signature" size={15} color="var(--fg-secondary)" />
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1, minWidth: 0 }}>
          <span style={{ fontSize: 13, color: 'var(--fg-primary)', fontWeight: 500 }}>凌云智算 — B 轮投委会备忘录</span>
          <Badge tone={phase === 'streaming' ? 'ai' : 'warning'} dot>{phase === 'streaming' ? '生成中' : '草稿'}</Badge>
          <span style={{ fontSize: 11, color: 'var(--fg-tertiary)' }}>{phase === 'streaming' ? 'AI 正在流式写作' : '2 分钟前 · 已自动保存'}</span>
        </div>
        <Button size="sm" variant="ghost" leading="history">版本 (v4)</Button>
        <Button size="sm" variant="ghost" leading="eye">预览</Button>
        <Button size="sm" leading="download">导出 PDF</Button>
        <Button size="sm" variant="primary" leading="send">提交 IC</Button>
      </div>

      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <div style={{
          width: 200, borderRight: '1px solid var(--border-subtle)',
          background: 'var(--bg-surface)', padding: '16px 10px', flexShrink: 0, overflow: 'auto',
        }}>
          <div style={{ fontSize: 10, color: 'var(--fg-tertiary)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 500, padding: '4px 10px 8px' }}>大纲</div>
          {MEMO_SECTIONS.map((s, i) => (
            <button key={s.id} onClick={() => setActive(s.id)} style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 8,
              padding: '6px 10px', borderRadius: 4, border: 'none',
              background: active === s.id ? 'var(--bg-active)' : 'transparent',
              color: active === s.id ? 'var(--fg-primary)' : 'var(--fg-secondary)',
              fontSize: 12.5, cursor: 'pointer', fontFamily: 'var(--font-sans)',
              textAlign: 'left', fontWeight: active === s.id ? 500 : 400,
            }}>
              <span style={{ fontSize: 10, fontFamily: 'var(--font-numeric)', color: 'var(--fg-tertiary)', width: 14 }}>{String(i+1).padStart(2, '0')}</span>
              {s.label}
            </button>
          ))}
          <div style={{ height: 1, background: 'var(--border-subtle)', margin: '16px 8px' }} />
          <div style={{ fontSize: 10, color: 'var(--fg-tertiary)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 500, padding: '4px 10px 8px' }}>来源 · 12 引用</div>
          {SOURCES.slice(0, 5).map(s => (
            <div key={s.id} style={{ padding: '5px 10px', display: 'flex', gap: 6, alignItems: 'flex-start' }}>
              <span style={{ fontSize: 10, color: 'var(--accent-400)', fontFamily: 'var(--font-mono)', marginTop: 2 }}>[{s.id}]</span>
              <div style={{ fontSize: 11, color: 'var(--fg-secondary)', lineHeight: 1.4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>{s.title}</div>
            </div>
          ))}
        </div>

        <div style={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column' }}>
          <div style={{ maxWidth: 780, margin: '0 auto', padding: '36px 32px 80px', width: '100%', boxSizing: 'border-box' }}>
            {MEMO_CONTENT.map((p, i) => <MemoBlock key={i} block={p} idx={i} visibleChars={visibleChars} streaming={phase === 'streaming'} />)}

            {/* AI inline suggestion */}
            {phase === 'final' && (
              <div style={{
                background: 'var(--accent-muted)', border: '1px solid rgba(0,195,232,0.25)',
                borderRadius: 6, padding: 14, margin: '24px 0', display: 'flex', gap: 12,
              }}>
                <div style={{
                  width: 22, height: 22, borderRadius: 4,
                  background: 'var(--accent)', color: '#05070F',
                  fontWeight: 600, fontSize: 10, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0, marginTop: 1,
                }}>
                  <Icon name="sparkles" size={11} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, color: 'var(--fg-primary)', lineHeight: 1.65 }}>
                    <strong style={{ fontWeight: 500 }}>建议补充:</strong> "竞争格局" 章节尚未填充。可基于尽调中的对比表(凌云 vs 秦淮数据)自动生成,并加入商汤大装置作为第三对标。
                  </div>
                  <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
                    <Button variant="accent" size="xs" leading="sparkles">生成章节</Button>
                    <Button variant="ghost" size="xs">稍后</Button>
                    <Button variant="ghost" size="xs">不需要</Button>
                  </div>
                </div>
              </div>
            )}

            {phase === 'streaming' && (
              <div style={{ textAlign: 'center', color: 'var(--accent-400)', fontSize: 11, padding: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                <Icon name="loader-circle" size={11} style={{ animation: 'spin 1s linear infinite' }} />
                AI 正在基于尽调数据流式生成 · 已引用 {Object.keys(visibleChars).length * 2} 处来源
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const MemoEmpty = ({ onStart }) => (
  <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-base)' }}>
    <Card style={{ width: 540, padding: 32 }}>
      <AiMark label="新建投委会备忘录" />
      <h2 style={{ fontSize: 20, fontWeight: 600, color: 'var(--fg-primary)', margin: '12px 0 6px', letterSpacing: '-0.01em' }}>从尽调结果一键生成 IC 备忘录</h2>
      <div style={{ fontSize: 13, color: 'var(--fg-tertiary)', lineHeight: 1.65 }}>
        AI 会根据已完成的尽调报告与行业调研,流式撰写标准 8 章节备忘录,并在每段自动插入 citation。
      </div>
      <Card style={{ padding: 12, marginTop: 16, background: 'var(--bg-inset)' }}>
        <Label>基于</Label>
        <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 6 }}>
          {[
            { icon: 'clipboard-check', label: '凌云智算 · 尽调报告', meta: '62% · 11 份资料' },
            { icon: 'telescope',       label: 'AI 基础设施 · 行业调研', meta: 'v3 · 12 节' },
            { icon: 'columns-3',       label: '凌云智算 vs 秦淮数据 对比',   meta: '12 项指标' },
          ].map((r, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Icon name={r.icon} size={13} color="var(--fg-secondary)" />
              <span style={{ fontSize: 12.5, color: 'var(--fg-primary)' }}>{r.label}</span>
              <span style={{ fontSize: 11, color: 'var(--fg-tertiary)' }}>{r.meta}</span>
            </div>
          ))}
        </div>
      </Card>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16, gap: 8 }}>
        <Button size="md" variant="ghost">空白开始</Button>
        <Button size="md" variant="accent" leading="sparkles" onClick={onStart}>AI 流式生成</Button>
      </div>
    </Card>
  </div>
);

const MemoBlock = ({ block, idx, visibleChars, streaming }) => {
  // Find paragraph index amongst streamable paragraphs
  const pIdx = MEMO_CONTENT.filter(p => p.text && !p.heading).indexOf(block);
  const chars = streaming ? (visibleChars[pIdx] ?? 0) : (block.text?.length || 0);

  if (block.heading === 'h1') {
    return <h1 style={{ fontSize: 30, fontWeight: 600, color: 'var(--fg-primary)', margin: '0 0 8px', letterSpacing: '-0.02em', lineHeight: 1.2 }}>{block.text}</h1>;
  }
  if (block.heading === 'meta') {
    return <div style={{ fontSize: 12.5, color: 'var(--fg-tertiary)', marginBottom: 24, fontFamily: 'var(--font-sans)' }}>{block.text}</div>;
  }
  if (block.heading === 'kpis') {
    return (
      <div style={{
        background: 'var(--bg-elevated)', border: '1px solid var(--border-default)',
        borderRadius: 8, padding: 16, margin: '8px 0 28px',
        display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16,
      }}>
        {[
          ['轮次',         'B 轮'],
          ['拟投资额',     '¥3.2 亿'],
          ['Pre-money',   '¥18 亿'],
          ['认购比例',     '17.8%'],
          ['签约 ARR',    '¥7.8 亿'],
          ['EV / ARR',    '2.3×'],
          ['预计 MOIC',   '2.8-3.5×'],
          ['预计 IRR',    '38-46%'],
        ].map(([l, v], i) => (
          <div key={l}>
            <Label>{l}</Label>
            <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--fg-primary)', marginTop: 4, fontVariantNumeric: 'tabular-nums' }}>{v}</div>
          </div>
        ))}
      </div>
    );
  }
  if (block.heading === 'h2') {
    return <h2 style={{ fontSize: 20, fontWeight: 600, color: 'var(--fg-primary)', margin: '32px 0 12px', letterSpacing: '-0.01em' }}>{block.text}</h2>;
  }

  // Paragraph with inline citations
  const visible = block.text.slice(0, chars);
  const isActive = streaming && pIdx >= 0 && chars < block.text.length && chars > 0;

  const cites = (block.citations || []).filter(c => c[0] <= chars).sort((a, b) => a[0] - b[0]);
  const parts = [];
  let cursor = 0;
  cites.forEach((c, i) => {
    const at = Math.min(c[0], visible.length);
    if (at > cursor) parts.push(<span key={`t${i}`}>{visible.slice(cursor, at)}</span>);
    parts.push(<CitationChip key={`c${i}`} n={c[1]} source={c[2]} />);
    cursor = at;
  });
  if (cursor < visible.length) parts.push(<span key="end">{visible.slice(cursor)}</span>);

  return (
    <p style={{
      fontSize: 14, color: 'var(--fg-primary)', lineHeight: 1.8, margin: '0 0 16px',
      letterSpacing: 0,
    }}>
      {parts}
      {isActive && (
        <span style={{
          display: 'inline-block', width: 6, height: 15, background: 'var(--accent)',
          marginLeft: 2, verticalAlign: 'middle', animation: 'blink 1s infinite', borderRadius: 1,
        }} />
      )}
    </p>
  );
};

window.Memo = Memo;
