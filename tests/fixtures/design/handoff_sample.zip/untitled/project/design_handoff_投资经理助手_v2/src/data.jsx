// data.jsx — seeded fixtures for AI 大模型基础设施 domain
// All numbers are illustrative. Companies are real names; specifics are fabricated for demo.

const SOURCES = [
  { id: 1, type: 'filing',  title: '寒武纪 2025 年度报告',    meta: '2026-03-28 · 163 页', icon: 'file-text' },
  { id: 2, type: 'filing',  title: '海光信息招股说明书',      meta: '2025-11-12 · 412 页', icon: 'file-text' },
  { id: 3, type: 'wind',    title: 'Wind 万得 · AI 芯片板块',  meta: '实时 · 34 家上市公司',  icon: 'bar-chart-3' },
  { id: 4, type: 'expert',  title: '专家访谈:某头部云厂商采购负责人', meta: '2026-04-08 · 68 分钟纪要', icon: 'mic' },
  { id: 5, type: 'expert',  title: '专家访谈:智算中心运营方 CTO',   meta: '2026-04-14 · 42 分钟纪要', icon: 'mic' },
  { id: 6, type: 'news',    title: '21世纪经济报道:国产算力集采',   meta: '2026-04-18',           icon: 'newspaper' },
  { id: 7, type: 'research',title: '中信证券 · 国产 AI 芯片深度',    meta: '2026-03-15 · 72 页',    icon: 'book-open' },
  { id: 8, type: 'tianyan', title: '启信宝 · 工商信息',              meta: '实时同步',             icon: 'building-2' },
  { id: 9, type: 'upload',  title: '凌云智算_BP_v4.pdf',            meta: '用户上传 · 48 页',       icon: 'upload-cloud' },
  { id: 10,type: 'upload',  title: '凌云智算_Q1财务_2026.xlsx',     meta: '用户上传 · 6 sheets',   icon: 'upload-cloud' },
  { id: 11,type: 'upload',  title: '创始人访谈_录音转写.txt',       meta: '用户上传 · 86 分钟',    icon: 'upload-cloud' },
  { id: 12,type: 'ifind',   title: '同花顺 iFind · 产业链数据',     meta: '每日同步',             icon: 'bar-chart-3' },
];

const PIPELINE = [
  { id: 'd-1', name: '凌云智算',    eng: 'LingYun AI',    stage: '尽调中',   sector: 'AI 基础设施', round: 'B 轮', size: '¥3.2亿', owner: '金立', progress: 62, updated: '2 小时前', status: 'active' },
  { id: 'd-2', name: '墨芯科技',    eng: 'Moffett AI',    stage: 'IC 审议',  sector: 'AI 芯片',    round: 'B+ 轮', size: '¥5.8亿', owner: '金立', progress: 88, updated: '昨天',     status: 'hot' },
  { id: 'd-3', name: '硅基流动',    eng: 'SiliconFlow',   stage: '初步接触', sector: '推理加速',   round: 'A 轮',  size: '¥1.5亿', owner: '陈可',  progress: 18, updated: '3 天前',   status: 'cold' },
  { id: 'd-4', name: '无问芯穹',    eng: 'Infinigence',   stage: '尽调中',   sector: '算力调度',   round: 'A+ 轮', size: '¥4.0亿', owner: '王楠',  progress: 45, updated: '5 天前',   status: 'active' },
  { id: 'd-5', name: '智谱 AI',     eng: 'Zhipu AI',      stage: '已投',     sector: '大模型',     round: 'D 轮',  size: '¥8.5亿', owner: '金立', progress: 100, updated: '2 周前',   status: 'invested' },
  { id: 'd-6', name: '阶跃星辰',    eng: 'Step Fun',      stage: '已 Pass',  sector: '大模型',     round: 'B 轮',  size: '¥6.0亿', owner: '陈可',  progress: 100, updated: '3 周前',   status: 'pass' },
];

const TARGET = {
  id: 'd-1',
  name: '凌云智算',
  eng: 'LingYun AI Computing',
  logo: 'LY',
  description: '面向大模型训练的 GPU 智算中心运营商,在华东、华北运营两个万卡规模 AI 算力集群,服务头部大模型厂商与科研机构。',
  sector: 'AI 基础设施 · 智算中心',
  stage: 'B 轮',
  ask: '¥3.2 亿',
  valuation: '¥18 亿 pre-money',
  ownership: '17.8%',
  founded: '2023-05',
  hq: '上海',
  employees: 86,
  founder: '张云峰',
  founderBg: '前阿里云智能副总裁,GPU 集群架构 12 年经验',
  kpis: [
    { label: '已部署卡量',   value: '12,800', unit: '张 GPU', delta: '+48%', deltaType: 'up' },
    { label: '2025 营收',   value: '4.2',     unit: '亿元',    delta: '+312%', deltaType: 'up' },
    { label: '毛利率',       value: '38.6',   unit: '%',       delta: '+6.2pp', deltaType: 'up' },
    { label: '头部客户占比', value: '72',     unit: '%',       delta: '+14pp',  deltaType: 'warning' },
  ],
};

// Industry map nodes for 产业链图谱
const INDUSTRY_NODES = [
  // Upstream
  { id: 'gpu-foreign', layer: 0, x: 0.08, y: 0.22, label: 'GPU 芯片', sub: 'NVIDIA / AMD', kind: 'foreign', highlight: true },
  { id: 'gpu-domestic', layer: 0, x: 0.08, y: 0.45, label: '国产 AI 芯片', sub: '华为昇腾 / 寒武纪 / 海光', kind: 'domestic', highlight: true },
  { id: 'hbm',        layer: 0, x: 0.08, y: 0.68, label: 'HBM 存储', sub: 'SK海力士 / 三星 / 长鑫',  kind: 'component' },
  { id: 'optics',     layer: 0, x: 0.08, y: 0.86, label: '光模块 / 交换机',  sub: '中际旭创 / 新易盛',       kind: 'component' },

  // Midstream - server & integration
  { id: 'server',     layer: 1, x: 0.35, y: 0.28, label: 'AI 服务器',   sub: '浪潮 / 中科曙光 / 联想', kind: 'integration' },
  { id: 'idc',        layer: 1, x: 0.35, y: 0.58, label: '智算中心',   sub: '凌云智算 / 商汤大装置 / 秦淮数据', kind: 'target', highlight: true },
  { id: 'cloud',      layer: 1, x: 0.35, y: 0.82, label: '公有云 GPU', sub: '阿里云 / 华为云 / 火山',   kind: 'integration' },

  // Framework / middleware
  { id: 'framework',  layer: 2, x: 0.60, y: 0.28, label: '训练框架',    sub: 'PyTorch / MindSpore',   kind: 'software' },
  { id: 'scheduler',  layer: 2, x: 0.60, y: 0.55, label: '算力调度',    sub: '无问芯穹 / 硅基流动',   kind: 'software' },
  { id: 'mlops',      layer: 2, x: 0.60, y: 0.82, label: 'MLOps 平台',  sub: '九章云极 / 星云 Clustar', kind: 'software' },

  // Downstream - application
  { id: 'foundation', layer: 3, x: 0.88, y: 0.22, label: '基础模型厂商', sub: '智谱 / 月之暗面 / MiniMax', kind: 'application', highlight: true },
  { id: 'vertical',   layer: 3, x: 0.88, y: 0.48, label: '垂直大模型',   sub: '金融 / 医疗 / 法律', kind: 'application' },
  { id: 'research',   layer: 3, x: 0.88, y: 0.70, label: '科研机构',     sub: '中科院 / 智源 / 上海AI Lab', kind: 'application' },
  { id: 'enterprise', layer: 3, x: 0.88, y: 0.90, label: '企业自建',     sub: '字节 / 腾讯 / 华为',      kind: 'application' },
];

const INDUSTRY_EDGES = [
  ['gpu-foreign', 'server'], ['gpu-foreign', 'cloud'],
  ['gpu-domestic', 'server'], ['gpu-domestic', 'idc'], ['gpu-domestic', 'cloud'],
  ['hbm', 'server'], ['hbm', 'idc'],
  ['optics', 'idc'], ['optics', 'cloud'],
  ['server', 'idc'], ['server', 'cloud'],
  ['idc', 'framework'], ['idc', 'scheduler'], ['idc', 'mlops'],
  ['cloud', 'framework'], ['cloud', 'scheduler'],
  ['framework', 'foundation'], ['framework', 'research'],
  ['scheduler', 'foundation'], ['scheduler', 'vertical'], ['scheduler', 'enterprise'],
  ['mlops', 'vertical'], ['mlops', 'enterprise'],
];

// Industry research — market sizing
const MARKET_SERIES = [
  { year: '2021', value: 220,  seg: [60, 100, 40, 20] },
  { year: '2022', value: 380,  seg: [90, 170, 80, 40] },
  { year: '2023', value: 720,  seg: [140, 340, 160, 80] },
  { year: '2024', value: 1380, seg: [220, 680, 320, 160] },
  { year: '2025', value: 2480, seg: [340, 1240, 620, 280] },
  { year: '2026', value: 3820, seg: [480, 1950, 980, 410], projected: true },
  { year: '2027', value: 5460, seg: [620, 2820, 1450, 570], projected: true },
  { year: '2028', value: 7280, seg: [780, 3780, 1980, 740], projected: true },
];

const COMPARE_TARGETS = [
  {
    id: 'lingyun',
    name: '凌云智算', eng: 'LingYun AI',
    status: '尽调中',
    metrics: {
      '运营 GPU 卡量': { v: '12,800 张', w: 'LY' },
      '2025 营收':     { v: '¥4.2 亿', w: 'LY' },
      '营收增速':     { v: '+312%',    w: 'LY' },
      '毛利率':       { v: '38.6%',    w: null },
      '头部客户占比': { v: '72%',      w: null, warn: true },
      '签约合同 ARR': { v: '¥7.8 亿',  w: 'LY' },
      '电价优势':     { v: '0.38 元/度', w: 'LY' },
      '国产化比例':   { v: '34%',      w: null },
      '融资阶段':     { v: 'B 轮',      w: null },
      'Pre-money 估值': { v: '¥18 亿', w: null },
      'EV / ARR':    { v: '2.3×',      w: 'LY' },
      '创始人背景':   { v: '前阿里云副总裁', w: 'LY' },
    },
  },
  {
    id: 'qinhuai',
    name: '秦淮数据',  eng: 'Chindata',
    status: '对比参考',
    metrics: {
      '运营 GPU 卡量': { v: '18,500 张', w: 'CD' },
      '2025 营收':     { v: '¥12.5 亿',  w: 'CD' },
      '营收增速':     { v: '+85%',      w: null },
      '毛利率':       { v: '41.2%',     w: 'CD' },
      '头部客户占比': { v: '58%',       w: 'CD' },
      '签约合同 ARR': { v: '¥15.2 亿',  w: 'CD' },
      '电价优势':     { v: '0.42 元/度', w: null },
      '国产化比例':   { v: '42%',       w: 'CD' },
      '融资阶段':     { v: '已上市',     w: 'CD' },
      'Pre-money 估值': { v: '—',        w: null },
      'EV / ARR':    { v: '3.8×',       w: null },
      '创始人背景':   { v: '前微软亚太数据中心', w: null },
    },
  },
];

const AI_SUGGESTIONS = {
  research: [
    '帮我整理 2026 年国产 AI 芯片替代进度',
    '对比寒武纪和华为昇腾的技术路线',
    '这个赛道的盈利模型拆解',
  ],
  dd: [
    '基于上传资料生成 SWOT 分析',
    '凌云智算和秦淮数据对比',
    '检查财务数据一致性',
  ],
  memo: [
    '补充竞争格局章节',
    '生成估值敏感性表',
    '根据风险章节建议缓释措施',
  ],
};

Object.assign(window, {
  SOURCES, PIPELINE, TARGET,
  INDUSTRY_NODES, INDUSTRY_EDGES, MARKET_SERIES,
  COMPARE_TARGETS, AI_SUGGESTIONS,
});
