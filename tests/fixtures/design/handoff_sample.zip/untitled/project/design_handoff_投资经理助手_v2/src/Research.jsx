// Research.jsx — 行业调研 surface
// Multi-step flow: 空白 → AI 生成 → 编辑/探索 → 导出
// Signature moment: 产业链图谱 with AI streaming annotations

const RESEARCH_SECTIONS = [
  { id: 'overview',    label: '概要',       icon: 'file-text' },
  { id: 'sizing',      label: '市场规模',   icon: 'trending-up' },
  { id: 'chain',       label: '产业链图谱', icon: 'git-branch' },
  { id: 'players',     label: '主要玩家',   icon: 'users' },
  { id: 'drivers',     label: '驱动因素',   icon: 'zap' },
  { id: 'risks',       label: '风险与边界', icon: 'alert-triangle' },
];

const Research = ({ onGoTo }) => {
  const [phase, setPhase] = useState('generated'); // 'empty' | 'generating' | 'generated'
  const [activeSection, setActiveSection] = useState('chain');
  const [hoverNode, setHoverNode] = useState(null);
  useLucide(phase + activeSection);

  if (phase === 'empty') return <ResearchEmpty onStart={() => {
    setPhase('generating');
    setTimeout(() => setPhase('generated'), 2800);
  }} />;

  if (phase === 'generating') return <ResearchGenerating />;

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: 'var(--bg-base)' }}>
      {/* Header */}
      <div style={{
        padding: '12px 24px', borderBottom: '1px solid var(--border-subtle)',
        background: 'var(--bg-surface)', display: 'flex', alignItems: 'center', gap: 14,
      }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <h1 style={{ fontSize: 15, fontWeight: 500, margin: 0, color: 'var(--fg-primary)' }}>AI 基础设施 · 智算中心</h1>
            <Badge tone="ai" dot>AI 生成</Badge>
            <Badge tone="subtle">v3 · 12 节</Badge>
          </div>
          <div style={{ fontSize: 11.5, color: 'var(--fg-tertiary)', marginTop: 3 }}>
            生成于 2026-04-22 08:40 · 接入 7 个数据源 · 引用 42 处 · 已保存
          </div>
        </div>
        <Button size="sm" variant="ghost" leading="history">版本</Button>
        <Button size="sm" leading="share-2">分享</Button>
        <Button size="sm" leading="download">导出</Button>
        <Button size="sm" variant="primary" leading="file-plus" onClick={() => onGoTo('memo')}>转为备忘录</Button>
      </div>

      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Section TOC */}
        <div style={{
          width: 180, borderRight: '1px solid var(--border-subtle)',
          background: 'var(--bg-surface)', padding: '12px 8px',
          flexShrink: 0, overflow: 'auto',
        }}>
          <div style={{ fontSize: 10, color: 'var(--fg-tertiary)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 500, padding: '4px 10px 8px' }}>章节</div>
          {RESEARCH_SECTIONS.map(s => (
            <button key={s.id} onClick={() => setActiveSection(s.id)} style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 8,
              padding: '6px 10px', borderRadius: 4, border: 'none',
              background: activeSection === s.id ? 'var(--bg-active)' : 'transparent',
              color: activeSection === s.id ? 'var(--fg-primary)' : 'var(--fg-secondary)',
              fontSize: 12.5, cursor: 'pointer', fontFamily: 'var(--font-sans)',
              textAlign: 'left', fontWeight: activeSection === s.id ? 500 : 400,
            }}>
              <Icon name={s.icon} size={13} />
              {s.label}
            </button>
          ))}
          <div style={{ height: 1, background: 'var(--border-subtle)', margin: '12px 8px' }} />
          <div style={{ fontSize: 10, color: 'var(--fg-tertiary)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 500, padding: '4px 10px 8px' }}>已引用来源</div>
          {SOURCES.slice(0, 4).map(s => (
            <div key={s.id} style={{ padding: '6px 10px', display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <span style={{ fontSize: 10, color: 'var(--accent-400)', fontFamily: 'var(--font-mono)', marginTop: 2 }}>[{s.id}]</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 11.5, color: 'var(--fg-secondary)', lineHeight: 1.4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.title}</div>
                <div style={{ fontSize: 10, color: 'var(--fg-tertiary)', marginTop: 1 }}>{s.meta}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Main content */}
        <div style={{ flex: 1, overflow: 'auto', padding: '24px 32px 64px' }}>
          {activeSection === 'overview' && <ResearchOverview />}
          {activeSection === 'sizing' && <ResearchSizing />}
          {activeSection === 'chain' && <IndustryChain hoverNode={hoverNode} setHoverNode={setHoverNode} />}
          {activeSection === 'players' && <ResearchPlayers />}
          {activeSection === 'drivers' && <ResearchDrivers />}
          {activeSection === 'risks' && <ResearchRisks />}
        </div>
      </div>
    </div>
  );
};

const ResearchEmpty = ({ onStart }) => (
  <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-base)' }}>
    <Card style={{ width: 520, padding: 32 }}>
      <AiMark label="新建行业调研" />
      <h2 style={{ fontSize: 20, fontWeight: 600, color: 'var(--fg-primary)', margin: '12px 0 6px', letterSpacing: '-0.01em' }}>告诉 AI 你想研究什么赛道</h2>
      <div style={{ fontSize: 13, color: 'var(--fg-tertiary)', lineHeight: 1.65 }}>
        会自动接入 Wind、iFind、研报、专家访谈纪要,并生成市场规模、产业链、主要玩家、风险评估等章节。
      </div>
      <div style={{
        marginTop: 20, background: 'var(--bg-inset)',
        border: '1px solid var(--border-default)', borderRadius: 6, padding: 12,
      }}>
        <textarea
          defaultValue="AI 基础设施 / 智算中心运营商 — 国产化替代进程与盈利模型"
          rows={3}
          style={{
            width: '100%', background: 'transparent', border: 'none', outline: 'none',
            color: 'var(--fg-primary)', fontSize: 13, fontFamily: 'var(--font-sans)',
            resize: 'none', lineHeight: 1.6,
          }}
        />
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
          <Badge>Wind · 万得</Badge>
          <Badge>同花顺 iFind</Badge>
          <Badge>中信研报</Badge>
          <Badge>专家访谈 · 3 份</Badge>
          <Badge tone="subtle">+ 接入</Badge>
        </div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16, gap: 8 }}>
        <Button size="md" variant="ghost">取消</Button>
        <Button size="md" variant="accent" leading="sparkles" onClick={onStart}>AI 生成调研</Button>
      </div>
    </Card>
  </div>
);

const ResearchGenerating = () => {
  const steps = [
    { label: '检索 Wind 行业数据', done: true },
    { label: '解析 7 份研报与访谈纪要', done: true },
    { label: '构建产业链图谱', done: true, active: true },
    { label: '汇总主要玩家与竞争格局', done: false },
    { label: '生成风险与边界分析', done: false },
  ];
  return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-base)' }}>
      <Card style={{ width: 480, padding: 28 }}>
        <AiMark label="生成中" />
        <h2 style={{ fontSize: 18, fontWeight: 500, color: 'var(--fg-primary)', margin: '12px 0 4px' }}>AI 正在构建你的行业调研</h2>
        <div style={{ fontSize: 12, color: 'var(--fg-tertiary)' }}>预计还需 8 秒 · 已引用 12 条来源</div>
        <div style={{ marginTop: 20, display: 'flex', flexDirection: 'column', gap: 10 }}>
          {steps.map((s, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{
                width: 16, height: 16, borderRadius: '50%',
                background: s.done ? 'var(--accent-muted)' : 'var(--bg-inset)',
                border: `1px solid ${s.done ? 'rgba(0,195,232,0.4)' : 'var(--border-default)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              }}>
                {s.done && <Icon name="check" size={10} color="var(--accent-400)" />}
                {s.active && <Icon name="loader-circle" size={10} color="var(--accent-400)" style={{ animation: 'spin 1s linear infinite' }} />}
              </div>
              <span style={{ fontSize: 13, color: s.done || s.active ? 'var(--fg-primary)' : 'var(--fg-tertiary)' }}>{s.label}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

// === Section content ===

const ResearchOverview = () => (
  <div style={{ maxWidth: 820 }}>
    <SectionHeader title="概要" subtitle="AI 基础设施 · 智算中心赛道" />
    <p style={{ fontSize: 14, color: 'var(--fg-primary)', lineHeight: 1.8 }}>
      智算中心(AI 数据中心)是承接大模型训练与推理需求的核心基础设施。2025 年国内市场规模 ¥2480 亿,同比增长 79%
      <CitationChip n="1" source="Wind · AI 芯片板块" />。市场分为训练集群、推理集群、混合集群三类;训练集群由头部大模型厂商主导采购,推理集群正在随 AI 应用下沉快速增长。
      国产芯片替代率已从 2024 年 18% 上升至 34%<CitationChip n="2" source="中信证券 · 国产 AI 芯片深度" />,华为昇腾 910B 成为主要替代方案。
      我们认为未来 18 个月内,具备电价优势 + 国产芯片调优能力 + 绑定头部客户的独立运营商,是最具投资价值的切入点<CitationChip n="3" source="专家访谈 · 某云厂商采购负责人" />。
    </p>
    <KeyTakeaways items={[
      ['市场规模',   '¥2480亿', '2025 实际,2028 预计 ¥7280亿', 'neutral'],
      ['国产化率',   '34%',     '2024 → 2026 上升 16pp',        'up'],
      ['关键客户',   '6 家',    '前六大占市场采购 62%',          'warning'],
      ['利用率',     '68%',     '行业平均,头部可达 82%',        'up'],
    ]} />
  </div>
);

const ResearchSizing = () => (
  <div style={{ maxWidth: 820 }}>
    <SectionHeader title="市场规模" subtitle="2021–2028 · 训练 / 推理 / 数据标注 / 其他" />
    <Card style={{ padding: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
        <div style={{ fontSize: 11, color: 'var(--fg-tertiary)' }}>单位 ¥ 亿 · 堆叠柱状图</div>
        <div style={{ flex: 1 }} />
        {['训练', '推理', '标注', '其他'].map((l, i) => (
          <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: 'var(--fg-secondary)' }}>
            <span style={{ width: 9, height: 9, borderRadius: 2, background: `var(--viz-${i+1})` }} />
            {l}
          </div>
        ))}
      </div>
      <MarketChart />
      <div style={{ marginTop: 12, fontSize: 11.5, color: 'var(--fg-tertiary)', display: 'flex', justifyContent: 'space-between' }}>
        <span>来源:Wind 万得、iFind、中信研报 · AI 拼合估算</span>
        <span style={{ color: 'var(--accent-400)' }}>2026 起为预测值</span>
      </div>
    </Card>
    <p style={{ fontSize: 14, color: 'var(--fg-primary)', lineHeight: 1.8, marginTop: 16 }}>
      训练集群规模占比从 2021 年 45% 攀升至 2025 年 50%,反映大模型训练持续是最核心的算力消耗场景<CitationChip n="1" source="Wind · 行业结构数据" />。
      推理集群在 2024–2025 年增速领先 (CAGR 113%),随着 AI 应用进入生产阶段,2028 年预计推理会超过训练成为最大细分<CitationChip n="2" source="中信证券 · 深度报告" />。
    </p>
  </div>
);

const IndustryChain = ({ hoverNode, setHoverNode }) => (
  <div style={{ maxWidth: 1100 }}>
    <SectionHeader
      title="产业链图谱"
      subtitle="AI 基础设施 · 上游 → 中游 → 软件 → 下游"
      ai
      rightSlot={
        <div style={{ display: 'flex', gap: 6 }}>
          <Button size="xs" variant="ghost" leading="filter">国产化视图</Button>
          <Button size="xs" variant="ghost" leading="maximize-2">全屏</Button>
        </div>
      }
    />
    <Card style={{ padding: 0, overflow: 'hidden' }}>
      <div style={{ position: 'relative', height: 440, background: 'var(--bg-inset)' }}>
        <IndustryChainSvg hoverNode={hoverNode} setHoverNode={setHoverNode} />
        <div style={{
          position: 'absolute', top: 12, left: 16, fontSize: 10,
          color: 'var(--fg-tertiary)', letterSpacing: '0.08em', textTransform: 'uppercase',
        }}>上游</div>
        <div style={{ position: 'absolute', top: 12, left: '32%', fontSize: 10, color: 'var(--fg-tertiary)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>中游</div>
        <div style={{ position: 'absolute', top: 12, left: '58%', fontSize: 10, color: 'var(--fg-tertiary)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>平台 / 软件</div>
        <div style={{ position: 'absolute', top: 12, right: 16, fontSize: 10, color: 'var(--fg-tertiary)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>下游应用</div>
        {/* Legend */}
        <div style={{
          position: 'absolute', bottom: 12, left: 16, display: 'flex', gap: 14,
          fontSize: 11, color: 'var(--fg-secondary)',
        }}>
          <LegendDot color="var(--accent-400)" label="本项目标的" />
          <LegendDot color="var(--brand-300)" label="AI 标注重点节点" />
          <LegendDot color="var(--fg-tertiary)" label="其他节点" />
        </div>
        {/* Info panel on hover */}
        {hoverNode && (
          <div style={{
            position: 'absolute', bottom: 44, right: 16, width: 240,
            background: 'var(--bg-overlay)', border: '1px solid var(--border-default)',
            borderRadius: 6, padding: 12, boxShadow: 'var(--shadow-md)',
          }}>
            <div style={{ fontSize: 12.5, fontWeight: 500, color: 'var(--fg-primary)' }}>{hoverNode.label}</div>
            <div style={{ fontSize: 11.5, color: 'var(--fg-tertiary)', marginTop: 3 }}>{hoverNode.sub}</div>
            {hoverNode.highlight && (
              <div style={{ marginTop: 10, fontSize: 11, color: 'var(--fg-secondary)', lineHeight: 1.6, borderTop: '1px solid var(--border-subtle)', paddingTop: 8 }}>
                <AiMark label="AI 备注" style={{ marginBottom: 4 }}/>
                {CHAIN_NOTES[hoverNode.id] || '节点信息已接入实时工商与财务数据。'}
              </div>
            )}
          </div>
        )}
      </div>
    </Card>
    <div style={{ marginTop: 16, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
      {[
        { title: '国产替代关键点', body: '上游芯片仍是瓶颈,华为昇腾 910B 是当前最成熟的替代方案;HBM 存储 2026 年长鑫存储有望送样。', cite: '2' },
        { title: '凌云智算在哪里', body: '位于中游智算中心运营层,自有两个万卡集群,服务智谱、月之暗面等 3 家头部大模型厂商。', cite: '3' },
        { title: '格局演化', body: '中游集中度在快速提升 (CR3 从 42% → 58%),电价、位置、头部客户绑定是核心门槛。', cite: '4' },
      ].map((c, i) => (
        <Card key={i} style={{ padding: 12 }}>
          <div style={{ fontSize: 11, color: 'var(--accent-400)', fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 5 }}>AI 分析</div>
          <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--fg-primary)', marginBottom: 5 }}>{c.title}</div>
          <div style={{ fontSize: 12, color: 'var(--fg-secondary)', lineHeight: 1.6 }}>
            {c.body}<CitationChip n={c.cite} source={SOURCES[parseInt(c.cite)-1]?.title || '数据源'} />
          </div>
        </Card>
      ))}
    </div>
  </div>
);

const CHAIN_NOTES = {
  'gpu-foreign': 'NVIDIA H100/H200 在国内市场仍占 62% 存量。美方出口管制压力下,2026 年国内新增采购已显著下降。',
  'gpu-domestic': '华为昇腾 910B 是当前最成熟替代,实测大模型训练效率达 H100 的 70–85%,价格优势约 30%。',
  'idc': '本项目标的层。关键指标:单卡利用率、电价、头部客户绑定。凌云智算位于该层。',
  'foundation': '智谱、月之暗面、MiniMax 是智算中心前三大客户,合计占头部运营商 60%+ 采购量。',
};

const ResearchPlayers = () => (
  <div style={{ maxWidth: 820 }}>
    <SectionHeader title="主要玩家" subtitle="中游智算中心运营商 · 按规模排序" />
    <Card style={{ overflow: 'hidden' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5 }}>
        <thead>
          <tr style={{ background: 'var(--bg-surface)', borderBottom: '1px solid var(--border-default)' }}>
            {['公司', '属性', 'GPU 卡量', '2025 营收', '毛利率', '国产化', '融资状态'].map(h => (
              <th key={h} style={{ textAlign: 'left', padding: '8px 12px', fontSize: 10.5, color: 'var(--fg-tertiary)', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {[
            ['秦淮数据',  '已上市',    '18,500', '¥12.5亿', '41.2%', '42%', '$NASDAQ:CD'],
            ['凌云智算',  '本项目标的', '12,800', '¥4.2亿',  '38.6%', '34%', 'B 轮尽调中'],
            ['商汤大装置', '上市子公司', '16,000', '¥10.8亿', '32.4%', '38%', '已上市'],
            ['万国数据',  '已上市',    '8,200',  '¥6.5亿',  '28.1%', '26%', '$NASDAQ:GDS'],
            ['中科曙光',  'A 股',      '11,000', '¥9.1亿',  '24.8%', '58%', 'SH:603019'],
          ].map((r, i) => (
            <tr key={i} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
              <td style={{ padding: '10px 12px', color: 'var(--fg-primary)', fontWeight: 500 }}>
                {r[0]}
                {r[0] === '凌云智算' && <Badge tone="info" style={{ marginLeft: 6 }}>本项目</Badge>}
              </td>
              <td style={{ padding: '10px 12px', color: 'var(--fg-secondary)' }}>{r[1]}</td>
              <td style={{ padding: '10px 12px', color: 'var(--fg-primary)', fontVariantNumeric: 'tabular-nums', fontFamily: 'var(--font-numeric)' }}>{r[2]}</td>
              <td style={{ padding: '10px 12px', color: 'var(--fg-primary)', fontVariantNumeric: 'tabular-nums', fontFamily: 'var(--font-numeric)' }}>{r[3]}</td>
              <td style={{ padding: '10px 12px', color: 'var(--fg-primary)', fontVariantNumeric: 'tabular-nums', fontFamily: 'var(--font-numeric)' }}>{r[4]}</td>
              <td style={{ padding: '10px 12px', color: 'var(--fg-primary)', fontVariantNumeric: 'tabular-nums', fontFamily: 'var(--font-numeric)' }}>{r[5]}</td>
              <td style={{ padding: '10px 12px', color: 'var(--fg-secondary)', fontFamily: 'var(--font-mono)', fontSize: 11.5 }}>{r[6]}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Card>
  </div>
);

const ResearchDrivers = () => (
  <div style={{ maxWidth: 820 }}>
    <SectionHeader title="驱动因素" />
    {[
      { title: '大模型训练算力刚需', body: '头部 6 家基础模型厂商 2026 年计划训练算力采购合计 ¥420 亿,同比 +85%。单次训练周期缩短至 3–4 周,推动持续采购。', cite: '1' },
      { title: '国产芯片供给改善',  body: '华为昇腾 910B 2026 Q1 产能爬坡至月产 1.2 万张,解决历史"可用但买不到"的痛点。', cite: '2' },
      { title: '推理场景下沉',      body: 'AI 应用进入生产期,推理算力需求增速(CAGR 113%)首次超过训练,2028 年将成为最大细分。', cite: '3' },
      { title: '地方政策 + 电价',    body: '十地已发布智算专项规划,对头部运营商给予 0.05–0.12 元/度的电价补贴,持续至 2027 年。', cite: '4' },
    ].map((d, i) => (
      <div key={i} style={{ paddingLeft: 16, borderLeft: '2px solid var(--border-default)', marginBottom: 18 }}>
        <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--fg-primary)', marginBottom: 4 }}>{d.title}</div>
        <div style={{ fontSize: 13, color: 'var(--fg-secondary)', lineHeight: 1.7 }}>
          {d.body}<CitationChip n={d.cite} source={SOURCES[parseInt(d.cite)-1]?.title} />
        </div>
      </div>
    ))}
  </div>
);

const ResearchRisks = () => (
  <div style={{ maxWidth: 820 }}>
    <SectionHeader title="风险与边界" />
    {[
      { tone: 'warning', title: '供给侧过剩风险', body: '2024–2026 年新建智算中心产能扩张 +180%,已经超过下游需求增速。预计 2027 年局部区域会出现 20–30% 的空置率,利用率下降将直接压缩毛利。' },
      { tone: 'warning', title: '客户集中风险',   body: '前 6 大基础模型厂商占中游运营商采购 62%,任何头部客户的训练节奏调整(如 MoE 架构降低训练算力需求)都会导致收入波动。' },
      { tone: 'danger',  title: '地缘政治',       body: '若美方进一步收紧 H100 / H200 出口或限制国内对等算力规模,短期内会打乱头部客户训练节奏,中期内加速国产化但同时拉低行业整体效率。' },
      { tone: 'warning', title: '电价政策退坡',   body: '多数地方电价补贴政策到 2027 年底结束,续期不确定性较高。无电价优势的运营商毛利会从 40% 回落至 25–28%。' },
    ].map((r, i) => (
      <Card key={i} style={{ padding: 14, marginBottom: 10, borderLeft: `2px solid ${r.tone === 'danger' ? 'var(--danger)' : 'var(--warning)'}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
          <Icon name={r.tone === 'danger' ? 'alert-octagon' : 'alert-triangle'} size={14} color={r.tone === 'danger' ? 'var(--danger)' : 'var(--warning)'} />
          <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--fg-primary)' }}>{r.title}</div>
        </div>
        <div style={{ fontSize: 12.5, color: 'var(--fg-secondary)', lineHeight: 1.65 }}>{r.body}</div>
      </Card>
    ))}
  </div>
);

// --- helpers ---
const SectionHeader = ({ title, subtitle, ai, rightSlot }) => (
  <div style={{ marginBottom: 14 }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <h2 style={{ fontSize: 18, fontWeight: 600, margin: 0, color: 'var(--fg-primary)', letterSpacing: '-0.01em' }}>{title}</h2>
      {ai && <AiMark />}
      <div style={{ flex: 1 }} />
      {rightSlot}
    </div>
    {subtitle && <div style={{ fontSize: 12, color: 'var(--fg-tertiary)', marginTop: 4 }}>{subtitle}</div>}
  </div>
);

const KeyTakeaways = ({ items }) => (
  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginTop: 16 }}>
    {items.map(([l, v, sub, tone], i) => (
      <Card key={i} style={{ padding: 12 }}>
        <Label>{l}</Label>
        <div style={{ fontSize: 20, fontWeight: 600, color: 'var(--fg-primary)', margin: '6px 0 2px', fontVariantNumeric: 'tabular-nums' }}>{v}</div>
        <div style={{ fontSize: 11, color: tone === 'up' ? 'var(--success)' : tone === 'warning' ? 'var(--warning)' : 'var(--fg-tertiary)' }}>{sub}</div>
      </Card>
    ))}
  </div>
);

const LegendDot = ({ color, label }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
    <span style={{ width: 8, height: 8, borderRadius: '50%', background: color }} />
    {label}
  </div>
);

// --- Market chart (stacked bars, pure SVG) ---
const MarketChart = () => {
  const w = 720, h = 200, pad = { t: 10, r: 16, b: 28, l: 44 };
  const max = 8000;
  const barW = (w - pad.l - pad.r) / MARKET_SERIES.length - 10;
  const colors = ['var(--viz-1)', 'var(--viz-2)', 'var(--viz-3)', 'var(--viz-4)'];
  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
      {[0, 2000, 4000, 6000, 8000].map(g => {
        const y = h - pad.b - ((h - pad.t - pad.b) * g / max);
        return (
          <g key={g}>
            <line x1={pad.l} x2={w - pad.r} y1={y} y2={y} stroke="var(--border-subtle)" strokeDasharray="2 3" />
            <text x={pad.l - 6} y={y + 3} fontSize="10" fill="var(--fg-tertiary)" textAnchor="end" fontFamily="var(--font-numeric)">{g}</text>
          </g>
        );
      })}
      {MARKET_SERIES.map((d, i) => {
        const x = pad.l + i * ((w - pad.l - pad.r) / MARKET_SERIES.length) + 5;
        let yCursor = h - pad.b;
        return (
          <g key={d.year}>
            {d.seg.map((s, si) => {
              const barH = (h - pad.t - pad.b) * s / max;
              yCursor -= barH;
              return <rect key={si} x={x} y={yCursor} width={barW} height={barH} fill={colors[si]} opacity={d.projected ? 0.55 : 1} />;
            })}
            <text x={x + barW / 2} y={h - pad.b + 14} fontSize="10.5" fill={d.projected ? 'var(--accent-400)' : 'var(--fg-tertiary)'} textAnchor="middle" fontFamily="var(--font-sans)">
              {d.year}{d.projected ? 'E' : ''}
            </text>
            <text x={x + barW / 2} y={(h - pad.b) - ((h - pad.t - pad.b) * d.value / max) - 4} fontSize="10" fill="var(--fg-secondary)" textAnchor="middle" fontFamily="var(--font-numeric)">{d.value}</text>
          </g>
        );
      })}
    </svg>
  );
};

// --- Industry chain SVG ---
const IndustryChainSvg = ({ hoverNode, setHoverNode }) => {
  const W = 1000, H = 440;
  const pos = Object.fromEntries(INDUSTRY_NODES.map(n => [n.id, { x: n.x * W, y: n.y * H }]));
  return (
    <svg width="100%" height="100%" viewBox={`0 0 ${W} ${H}`} style={{ display: 'block' }} preserveAspectRatio="xMidYMid meet">
      <defs>
        <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto">
          <path d="M0,0 L10,5 L0,10 z" fill="var(--border-strong)" />
        </marker>
        <marker id="arrow-hl" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto">
          <path d="M0,0 L10,5 L0,10 z" fill="var(--accent)" />
        </marker>
      </defs>
      {/* Column dividers */}
      {[0.23, 0.48, 0.73].map(x => (
        <line key={x} x1={W * x} y1="40" x2={W * x} y2={H - 30} stroke="var(--border-subtle)" strokeDasharray="2 4" />
      ))}
      {/* Edges */}
      {INDUSTRY_EDGES.map(([a, b], i) => {
        const aP = pos[a], bP = pos[b];
        const hl = hoverNode && (hoverNode.id === a || hoverNode.id === b);
        const cx = (aP.x + bP.x) / 2;
        const d = `M${aP.x + 60} ${aP.y} C ${cx} ${aP.y}, ${cx} ${bP.y}, ${bP.x - 60} ${bP.y}`;
        return <path key={i} d={d} fill="none"
          stroke={hl ? 'var(--accent)' : 'var(--border-default)'}
          strokeWidth={hl ? 1.5 : 1}
          markerEnd={hl ? 'url(#arrow-hl)' : 'url(#arrow)'}
          opacity={hoverNode && !hl ? 0.25 : 1}
        />;
      })}
      {/* Nodes */}
      {INDUSTRY_NODES.map(n => {
        const p = pos[n.id];
        const isTarget = n.kind === 'target';
        const isHighlight = n.highlight;
        const bg = isTarget ? 'rgba(0,195,232,0.12)' : isHighlight ? 'rgba(91,108,255,0.08)' : 'var(--bg-elevated)';
        const stroke = isTarget ? 'var(--accent)' : isHighlight ? 'var(--brand-400)' : 'var(--border-default)';
        return (
          <g key={n.id}
             onMouseEnter={() => setHoverNode(n)}
             onMouseLeave={() => setHoverNode(null)}
             style={{ cursor: 'pointer' }}
          >
            <rect x={p.x - 60} y={p.y - 18} width={120} height={36} rx={6}
              fill={bg} stroke={stroke} strokeWidth={isTarget ? 1.5 : 1}
            />
            <text x={p.x} y={p.y - 3} fontSize="11.5" fill="var(--fg-primary)" textAnchor="middle" fontFamily="var(--font-sans)" fontWeight="500">{n.label}</text>
            <text x={p.x} y={p.y + 10} fontSize="9.5" fill="var(--fg-tertiary)" textAnchor="middle" fontFamily="var(--font-sans)">{n.sub}</text>
            {isTarget && (
              <circle cx={p.x + 55} cy={p.y - 13} r={3} fill="var(--accent)">
                <animate attributeName="r" values="3;5;3" dur="2s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="1;0.3;1" dur="2s" repeatCount="indefinite" />
              </circle>
            )}
          </g>
        );
      })}
    </svg>
  );
};

window.Research = Research;
