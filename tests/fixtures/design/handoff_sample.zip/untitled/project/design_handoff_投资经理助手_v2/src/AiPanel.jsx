// AiPanel.jsx — right-side copilot, context-aware
const AI_CONTEXT_LABEL = {
  dashboard: 'Fund II · 全局',
  research:  '行业 · AI 基础设施',
  dd:        '尽调 · 凌云智算',
  memo:      '备忘录 · 凌云智算 B 轮',
  screener:  '项目池 · 13 家',
  portfolio: '投后 · 23 家组合',
  library:   '资料库',
};

// Simulated streaming replies keyed by surface intent.
const AI_SCRIPTED = {
  research: {
    reply: '根据已接入的 Wind 万得、中信证券研报和 3 份专家访谈,2026 年国内智算中心市场规模预计 ¥3820 亿,同比增长 54%。驱动因素:(1) 大模型厂商训练需求持续爆发,头部玩家单季度算力采购超 ¥20 亿;(2) 国产 AI 芯片替代率从 2024 年 18% 上升至 34%,华为昇腾 910B 成为主力;(3) 政策端十地已发布算力专项规划。需警惕:供给侧扩张速度已超过需求增速,2027 年可能出现局部过剩。',
    citations: [
      { n: '1', source: 'Wind · AI 芯片板块', offset: 40 },
      { n: '2', source: '中信证券 · 国产 AI 芯片深度', offset: 102 },
      { n: '3', source: '专家访谈 · 某云厂商采购负责人', offset: 160 },
      { n: '4', source: '21世纪经济报道 · 算力集采', offset: 210 },
    ],
  },
  dd: {
    reply: '已完成对凌云智算 11 份上传材料的解析,识别出 3 处需要关注的数据一致性问题:(1) BP 中 2025 年营收 ¥4.5 亿,财务 sheet 为 ¥4.2 亿,差异来自是否包含代运营收入;(2) 头部客户占比 72%,集中于 3 家大模型厂商,需要追加客户访谈验证续约意向;(3) 电价优势 0.38 元/度 依赖地方政策补贴至 2027 年。其余材料与公开工商数据交叉验证通过。',
    citations: [
      { n: '1', source: '凌云智算_BP_v4.pdf p.18', offset: 34 },
      { n: '2', source: '凌云智算_Q1财务_2026.xlsx', offset: 62 },
      { n: '3', source: '启信宝 · 工商关联', offset: 228 },
    ],
  },
  memo: {
    reply: '建议在 "竞争格局" 章节补充以下内容:凌云智算与秦淮数据、商汤大装置构成国内智算三强格局。凌云在单卡利用率 (68%) 和签约 ARR 增速 (+312%) 上领先;但在总规模 (12,800 张 vs 秦淮 18,500 张)、国产化率 (34% vs 42%) 上落后。已自动生成对比表,可插入第 3 节后。',
    citations: [
      { n: '1', source: '秦淮数据 2025 年报', offset: 70 },
      { n: '2', source: 'Wind · 智算中心板块', offset: 140 },
    ],
  },
  default: {
    reply: '基于 Fund II 全部在投与在调项目,以下是今日需要关注的 3 件事:(1) 墨芯科技本周四上 IC,TS 条款已基本敲定;(2) 凌云智算尽调进展 62%,待补材料已向 GP 发送;(3) 硅基流动创始人将于周五来访,建议提前准备产品深度问题清单。',
    citations: [
      { n: '1', source: '项目管道', offset: 40 },
      { n: '2', source: '尽调进度追踪', offset: 86 },
    ],
  },
};

const AiPanel = ({ surface, onClose, onInsertToMemo }) => {
  const [msgs, setMsgs] = useState([
    { role: 'ai', text: '你好,Jin。我已经接入了当前上下文的数据源。你可以直接问我,或从下方建议开始。', citations: [] },
  ]);
  const [streaming, setStreaming] = useState(false);
  const [draft, setDraft] = useState('');
  const scrollRef = useRef(null);
  useLucide(msgs.length);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [msgs]);

  const send = (preset) => {
    const q = preset || draft;
    if (!q.trim()) return;
    setMsgs(m => [...m, { role: 'user', text: q }]);
    setDraft('');
    setStreaming(true);

    const key = preset && preset.includes('SWOT') ? 'dd'
              : preset && preset.includes('竞争') ? 'memo'
              : preset && preset.includes('对比') ? 'dd'
              : preset && preset.includes('整理') ? 'research'
              : preset && preset.includes('风险') ? 'memo'
              : surface in AI_SCRIPTED ? surface : 'default';
    const scripted = AI_SCRIPTED[key] || AI_SCRIPTED.default;
    const target = scripted.reply;
    const citations = scripted.citations;

    setMsgs(m => [...m, { role: 'ai', text: '', citations: [], _pendingCitations: citations }]);
    let i = 0;
    const step = Math.max(2, Math.floor(target.length / 80));
    const timer = setInterval(() => {
      i += step;
      setMsgs(m => m.map((msg, idx) => {
        if (idx !== m.length - 1) return msg;
        const visibleCitations = (msg._pendingCitations || []).filter(c => c.offset <= i);
        return { ...msg, text: target.slice(0, i), citations: visibleCitations };
      }));
      if (i >= target.length) {
        clearInterval(timer);
        setStreaming(false);
        setMsgs(m => m.map((msg, idx) => idx === m.length - 1 ? { ...msg, text: target, citations: msg._pendingCitations } : msg));
      }
    }, 40);
  };

  const suggestions = AI_SUGGESTIONS[surface] || AI_SUGGESTIONS.research;

  return (
    <div style={{
      width: 380, background: 'var(--bg-surface)',
      borderLeft: '1px solid var(--border-subtle)',
      display: 'flex', flexDirection: 'column', flexShrink: 0, height: '100%',
    }}>
      <div style={{
        padding: '10px 14px', borderBottom: '1px solid var(--border-subtle)',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <div style={{
          width: 22, height: 22, borderRadius: 5,
          background: 'var(--accent-muted)',
          border: '1px solid rgba(0,195,232,0.3)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name="sparkles" size={13} color="var(--accent-400)" />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, fontWeight: 500, color: 'var(--fg-primary)' }}>投资助手 Copilot</div>
          <div style={{ fontSize: 10.5, color: 'var(--fg-tertiary)', display: 'flex', alignItems: 'center', gap: 5, marginTop: 1 }}>
            <span style={{ width: 5, height: 5, background: '#55C08C', borderRadius: '50%' }} />
            上下文:{AI_CONTEXT_LABEL[surface] || '—'}
          </div>
        </div>
        <IconButton icon="refresh-cw" size={24} iconSize={12} title="重置对话" onClick={() => setMsgs([{ role: 'ai', text: '已重置。', citations: [] }])} />
        <IconButton icon="x" size={24} iconSize={13} title="关闭" onClick={onClose} />
      </div>

      <div ref={scrollRef} style={{
        flex: 1, overflow: 'auto', padding: '14px 14px 8px',
        display: 'flex', flexDirection: 'column', gap: 14,
      }}>
        {msgs.map((m, i) => (
          <AiMsg key={i} msg={m} isLast={i === msgs.length - 1} streaming={streaming} onInsertToMemo={onInsertToMemo} />
        ))}
        {streaming && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 10.5, color: 'var(--accent-400)', marginLeft: 28 }}>
            <Icon name="loader-circle" size={10} style={{ animation: 'spin 1s linear infinite' }} />
            检索中 · 已引用 {msgs[msgs.length-1]?.citations?.length || 0} 条来源
          </div>
        )}
      </div>

      <div style={{ padding: '0 12px 10px', display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {suggestions.map(s => (
          <button key={s} onClick={() => send(s)} disabled={streaming} style={{
            background: 'var(--bg-elevated)', border: '1px solid var(--border-default)',
            borderRadius: 4, padding: '5px 9px', fontSize: 11.5, color: 'var(--fg-secondary)',
            cursor: streaming ? 'not-allowed' : 'pointer', opacity: streaming ? 0.5 : 1,
            fontFamily: 'var(--font-sans)', whiteSpace: 'nowrap',
          }}>{s}</button>
        ))}
      </div>

      <div style={{ padding: 12, borderTop: '1px solid var(--border-subtle)' }}>
        <div style={{
          background: 'var(--bg-elevated)', border: '1px solid var(--border-default)',
          borderRadius: 6, padding: 8, display: 'flex', flexDirection: 'column', gap: 8,
        }}>
          <textarea
            value={draft}
            onChange={e => setDraft(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
            }}
            placeholder="问我任何关于这家公司、这个赛道、或你的组合的问题…"
            rows={2}
            style={{
              background: 'transparent', border: 'none', outline: 'none',
              color: 'var(--fg-primary)', fontSize: 12.5, fontFamily: 'var(--font-sans)',
              resize: 'none', lineHeight: 1.5, padding: 0,
            }}
          />
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <IconButton icon="paperclip" size={24} iconSize={13} title="附加资料" />
            <IconButton icon="at-sign" size={24} iconSize={13} title="引用公司/文档" />
            <IconButton icon="globe" size={24} iconSize={13} title="联网检索" />
            <div style={{ flex: 1 }} />
            <span style={{ fontSize: 10, color: 'var(--fg-tertiary)' }}>Shift + ⏎ 换行</span>
            <Button variant="accent" size="xs" onClick={() => send()} disabled={streaming || !draft.trim()}>
              发送
            </Button>
          </div>
        </div>
      </div>
      <style>{`@keyframes blink { 50% { opacity: 0 } } @keyframes spin { to { transform: rotate(360deg) } }`}</style>
    </div>
  );
};

// Render a message, with inline citation rendering
const AiMsg = ({ msg, isLast, streaming, onInsertToMemo }) => {
  // Render the text and splice in CitationChip at each citation.offset position.
  // Citations appear only when we've streamed past their offset (already filtered upstream).
  const renderText = () => {
    const cites = (msg.citations || []).slice().sort((a, b) => a.offset - b.offset);
    if (!cites.length) return msg.text;
    const parts = [];
    let cursor = 0;
    cites.forEach((c, i) => {
      const at = Math.min(c.offset, msg.text.length);
      if (at > cursor) parts.push(<span key={`t${i}`}>{msg.text.slice(cursor, at)}</span>);
      parts.push(<CitationChip key={`c${i}`} n={c.n} source={c.source} />);
      cursor = at;
    });
    if (cursor < msg.text.length) parts.push(<span key="end">{msg.text.slice(cursor)}</span>);
    return parts;
  };

  if (msg.role === 'user') {
    return (
      <div style={{ alignSelf: 'flex-end', maxWidth: '88%' }}>
        <div style={{
          background: 'var(--bg-elevated)', border: '1px solid var(--border-default)',
          borderRadius: 6, padding: '7px 11px', fontSize: 12.5, color: 'var(--fg-primary)',
          lineHeight: 1.55,
        }}>{msg.text}</div>
      </div>
    );
  }
  return (
    <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
      <div style={{
        width: 20, height: 20, borderRadius: 4, flexShrink: 0, marginTop: 1,
        background: 'var(--accent-muted)',
        border: '1px solid rgba(0,195,232,0.3)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name="sparkles" size={11} color="var(--accent-400)" />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 12.5, color: 'var(--fg-primary)', lineHeight: 1.65, wordBreak: 'break-word' }}>
          {renderText()}
          {isLast && streaming && (
            <span style={{
              display: 'inline-block', width: 6, height: 13, background: 'var(--accent)',
              marginLeft: 2, verticalAlign: 'middle', animation: 'blink 1s infinite',
              borderRadius: 1,
            }} />
          )}
        </div>
        {msg.text && !streaming && msg.citations && msg.citations.length > 0 && (
          <div style={{ marginTop: 8, display: 'flex', gap: 4, alignItems: 'center', flexWrap: 'wrap' }}>
            <span style={{ fontSize: 10, color: 'var(--fg-tertiary)', letterSpacing: '0.06em', textTransform: 'uppercase', marginRight: 4 }}>来源</span>
            {msg.citations.map(c => (
              <span key={c.n} style={{
                fontSize: 10.5, color: 'var(--fg-secondary)', fontFamily: 'var(--font-mono)',
                background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)',
                borderRadius: 3, padding: '1px 6px', display: 'inline-flex', gap: 4, alignItems: 'center',
              }}>
                <span style={{ color: 'var(--accent-400)' }}>[{c.n}]</span>
                {c.source}
              </span>
            ))}
          </div>
        )}
        {msg.text && !streaming && msg.role === 'ai' && msg !== msg.initial && (
          <div style={{ marginTop: 8, display: 'flex', gap: 4 }}>
            <IconButton icon="copy" size={22} iconSize={11} title="复制" />
            <IconButton icon="file-plus" size={22} iconSize={11} title="插入到备忘录" onClick={onInsertToMemo} />
            <IconButton icon="thumbs-up" size={22} iconSize={11} title="有用" />
            <IconButton icon="thumbs-down" size={22} iconSize={11} title="不准确" />
          </div>
        )}
      </div>
    </div>
  );
};

Object.assign(window, { AiPanel });
