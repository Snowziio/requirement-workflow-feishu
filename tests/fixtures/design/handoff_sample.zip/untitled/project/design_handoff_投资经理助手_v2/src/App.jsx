// App.jsx — top-level shell
const { useState: useAppState, useEffect: useAppEffect } = React;

const DEFAULTS = /*EDITMODE-BEGIN*/{
  "layout": "three-col",
  "density": "standard",
  "showAiByDefault": true
}/*EDITMODE-END*/;

const App = () => {
  const [theme, setTheme] = useAppState('dark');
  const [surface, setSurface] = useAppState('dashboard');
  const [activeDealId, setActiveDealId] = useAppState('d-1');
  const [aiOpen, setAiOpen] = useAppState(true);
  const [sidebarOpen, setSidebarOpen] = useAppState(true);
  const [tweaks, setTweaks] = useAppState(DEFAULTS);
  const [editMode, setEditMode] = useAppState(false);

  useAppEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  // Tweaks protocol
  useAppEffect(() => {
    const handler = (e) => {
      if (e.data?.type === '__activate_edit_mode') setEditMode(true);
      else if (e.data?.type === '__deactivate_edit_mode') setEditMode(false);
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);

  // Layout config
  useAppEffect(() => {
    if (tweaks.layout === 'single') { setSidebarOpen(false); setAiOpen(false); }
    else if (tweaks.layout === 'two-col') { setSidebarOpen(true); setAiOpen(false); }
    else { setSidebarOpen(true); setAiOpen(true); }
  }, [tweaks.layout]);

  const updateTweaks = (patch) => {
    setTweaks(t => ({ ...t, ...patch }));
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: patch }, '*');
  };

  // Lucide refresh on surface change
  useAppEffect(() => {
    const t = setTimeout(() => window.lucide && window.lucide.createIcons && window.lucide.createIcons(), 50);
    return () => clearTimeout(t);
  }, [surface, sidebarOpen, aiOpen]);

  const surfaceLabel = {
    dashboard: '工作台',
    research:  '行业调研',
    dd:        '尽调报告',
    memo:      '投委会备忘录',
    screener:  '项目筛选',
    portfolio: '投后组合',
    library:   '资料库',
  }[surface] || '';

  const breadcrumb = surface === 'dashboard'
    ? ['Fund II', '工作台']
    : surface === 'dd'
    ? ['Fund II', '尽调', '凌云智算']
    : surface === 'memo'
    ? ['Fund II', '备忘录', '凌云智算 B 轮']
    : surface === 'research'
    ? ['Fund II', '行业调研', 'AI 基础设施']
    : ['Fund II', surfaceLabel];

  const density = tweaks.density;
  const densityStyle = density === 'compact'
    ? { '--space-unit': '0.9' }
    : density === 'comfortable'
    ? { '--space-unit': '1.15' }
    : {};

  return (
    <div style={{
      display: 'flex', height: '100%', width: '100%',
      background: 'var(--bg-base)', color: 'var(--fg-primary)',
      fontFamily: 'var(--font-sans)',
      ...densityStyle,
    }}>
      <NavRail active={surface} onNavigate={setSurface} />
      {sidebarOpen && (
        <Sidebar
          surface={surface}
          activeDealId={activeDealId}
          onSelectDeal={setActiveDealId}
        />
      )}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, overflow: 'hidden' }}>
        <Topbar
          theme={theme}
          onToggleTheme={() => setTheme(t => t === 'dark' ? 'light' : 'dark')}
          breadcrumb={breadcrumb}
          aiOpen={aiOpen}
          onToggleAi={() => setAiOpen(o => !o)}
        />
        <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, overflow: 'hidden' }}>
            {surface === 'dashboard' && <Dashboard onNavigate={setSurface} />}
            {surface === 'research' && <Research onGoTo={setSurface} />}
            {surface === 'dd' && <DDReport onGoTo={setSurface} />}
            {surface === 'memo' && <Memo onGoTo={setSurface} />}
            {surface === 'screener' && <Placeholder title="项目筛选" icon="scan-search" />}
            {surface === 'portfolio' && <Placeholder title="投后组合" icon="briefcase" />}
            {surface === 'library' && <Placeholder title="资料库" icon="library" />}
          </div>
          {aiOpen && <AiPanel surface={surface} onClose={() => setAiOpen(false)} onInsertToMemo={() => setSurface('memo')} />}
        </div>
      </div>
      {editMode && <TweaksPanel tweaks={tweaks} onChange={updateTweaks} onClose={() => setEditMode(false)} />}
    </div>
  );
};

const Placeholder = ({ title, icon }) => (
  <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-base)' }}>
    <EmptyState icon={icon} title={title} body="此模块是整体工作台的一部分;当前演示聚焦于行业调研、尽调报告、投委会备忘录三个主流程。" />
  </div>
);

const TweaksPanel = ({ tweaks, onChange, onClose }) => (
  <div style={{
    position: 'fixed', right: 16, bottom: 16, width: 300, zIndex: 1000,
    background: 'var(--bg-overlay)', border: '1px solid var(--border-default)',
    borderRadius: 8, boxShadow: 'var(--shadow-lg)', padding: 14,
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
      <Icon name="sliders-horizontal" size={14} color="var(--fg-secondary)" />
      <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--fg-primary)' }}>Tweaks</span>
      <div style={{ flex: 1 }} />
      <IconButton icon="x" size={22} iconSize={12} onClick={onClose} />
    </div>
    <div style={{ marginBottom: 14 }}>
      <Label style={{ marginBottom: 6 }}>布局</Label>
      <div style={{ display: 'flex', gap: 4, background: 'var(--bg-inset)', padding: 2, borderRadius: 5, border: '1px solid var(--border-subtle)' }}>
        {[
          { id: 'single', label: '单栏', icon: 'square' },
          { id: 'two-col', label: '双栏', icon: 'columns-2' },
          { id: 'three-col', label: '三栏', icon: 'columns-3' },
        ].map(o => (
          <button key={o.id} onClick={() => onChange({ layout: o.id })} style={{
            flex: 1, height: 26, border: 'none', borderRadius: 4,
            background: tweaks.layout === o.id ? 'var(--bg-elevated)' : 'transparent',
            color: tweaks.layout === o.id ? 'var(--fg-primary)' : 'var(--fg-secondary)',
            cursor: 'pointer', fontSize: 11.5, fontFamily: 'var(--font-sans)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
            boxShadow: tweaks.layout === o.id ? 'var(--shadow-xs)' : 'none',
          }}>
            <Icon name={o.icon} size={11} />
            {o.label}
          </button>
        ))}
      </div>
      <div style={{ fontSize: 10.5, color: 'var(--fg-tertiary)', marginTop: 5, lineHeight: 1.5 }}>
        {tweaks.layout === 'single' && '全屏工作区,适合深度写作。AI 通过顶栏按钮召出。'}
        {tweaks.layout === 'two-col' && '主导航 + 工作区。AI 可按需召出。'}
        {tweaks.layout === 'three-col' && '完整工作台 · AI Copilot 常驻右侧。'}
      </div>
    </div>
    <div>
      <Label style={{ marginBottom: 6 }}>信息密度</Label>
      <div style={{ display: 'flex', gap: 4, background: 'var(--bg-inset)', padding: 2, borderRadius: 5, border: '1px solid var(--border-subtle)' }}>
        {['compact', 'standard', 'comfortable'].map(o => (
          <button key={o} onClick={() => onChange({ density: o })} style={{
            flex: 1, height: 26, border: 'none', borderRadius: 4,
            background: tweaks.density === o ? 'var(--bg-elevated)' : 'transparent',
            color: tweaks.density === o ? 'var(--fg-primary)' : 'var(--fg-secondary)',
            cursor: 'pointer', fontSize: 11.5, fontFamily: 'var(--font-sans)',
          }}>
            {o === 'compact' ? '紧凑' : o === 'standard' ? '标准' : '舒适'}
          </button>
        ))}
      </div>
    </div>
  </div>
);

window.App = App;
