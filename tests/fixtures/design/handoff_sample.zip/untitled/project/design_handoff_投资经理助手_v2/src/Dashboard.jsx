// Dashboard.jsx — global overview (entry point into the three workflows)
const Dashboard = ({ onNavigate }) => {
  useLucide(0);
  return (
    <div style={{ flex: 1, overflow: 'auto', padding: '24px 28px 48px', background: 'var(--bg-base)' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 4 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 600, margin: 0, color: 'var(--fg-primary)', letterSpacing: '-0.01em' }}>下午好,Jin。</h1>
          <div style={{ fontSize: 13, color: 'var(--fg-tertiary)', marginTop: 4 }}>Fund II · 2026 年 4 月 22 日 · 3 个项目需要你的关注</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Button size="sm" leading="import">导入</Button>
          <Button size="sm" variant="primary" leading="plus">新建项目</Button>
        </div>
      </div>

      {/* AI daily brief */}
      <div style={{
        marginTop: 20, background: 'var(--bg-elevated)',
        border: '1px solid var(--border-default)', borderRadius: 8, padding: 16,
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', top: 0, left: 0, width: 2, height: '100%', background: 'var(--accent)' }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
          <AiMark label="AI 每日简报" />
          <span style={{ fontSize: 11, color: 'var(--fg-tertiary)' }}>生成于 08:42 · 覆盖 6 个在研项目</span>
          <div style={{ flex: 1 }} />
          <IconButton icon="refresh-cw" size={22} iconSize={12} title="重新生成" />
        </div>
        <div style={{ fontSize: 13, color: 'var(--fg-primary)', lineHeight: 1.7 }}>
          凌云智算尽调进度 62%,客户访谈已完成 3/5,财务交叉验证发现 <span style={{ color: 'var(--warning)' }}>3 处差异</span><CitationChip n="1" source="凌云智算_Q1财务_2026.xlsx" />。
          墨芯科技 B+ 轮备忘录已定稿,本周四上 IC<CitationChip n="2" source="墨芯科技 — IC Memo" />。
          国产 AI 芯片板块本周涨 <span style={{ color: 'var(--market-up)', fontFamily: 'var(--font-numeric)' }}>▲ 4.8%</span>,华为昇腾 910B 供货改善为主要驱动<CitationChip n="3" source="Wind · 国产 AI 芯片板块" />。
        </div>
      </div>

      {/* KPI row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginTop: 16 }}>
        {[
          ['在管规模',  '¥32.5亿', '+2.1%',  'up'],
          ['在投项目',  '23',      '+2 本季', 'up'],
          ['活跃尽调',  '3',       '2 需关注', 'warning'],
          ['净 IRR',    '24.8%',   '−1.2pp', 'down'],
        ].map(([label, val, delta, tone], i) => (
          <Card key={i} style={{ padding: 14 }}>
            <Label>{label}</Label>
            <div style={{ fontSize: 24, fontWeight: 600, color: 'var(--fg-primary)', marginTop: 8, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.01em' }}>{val}</div>
            <div style={{ fontSize: 11, color: tone === 'up' ? 'var(--success)' : tone === 'down' ? 'var(--market-down)' : 'var(--warning)', marginTop: 4, fontFamily: 'var(--font-numeric)' }}>{delta}</div>
          </Card>
        ))}
      </div>

      {/* Workflow entries */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginTop: 20 }}>
        {[
          { id: 'research', icon: 'telescope',       title: '行业调研',        sub: '2 个进行中',   desc: '接入 Wind/iFind、研报与专家访谈,AI 输出市场结构与产业链图谱。', cta: '打开' },
          { id: 'dd',       icon: 'clipboard-check', title: '企业尽调报告',    sub: '3 个进行中',   desc: '拖拽上传 BP、财务、访谈,AI 自动结构化并生成多公司对比。',       cta: '打开' },
          { id: 'memo',     icon: 'file-signature',  title: '投委会备忘录',    sub: '2 个草稿',     desc: '一键从尽调生成 IC Memo,流式写作 + 实时 citation。',           cta: '打开' },
        ].map(w => (
          <Card key={w.id} interactive onClick={() => onNavigate(w.id)} style={{ padding: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <div style={{
                width: 28, height: 28, borderRadius: 6,
                background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Icon name={w.icon} size={15} color="var(--fg-secondary)" />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--fg-primary)' }}>{w.title}</div>
                <div style={{ fontSize: 11, color: 'var(--fg-tertiary)', marginTop: 1 }}>{w.sub}</div>
              </div>
              <Icon name="arrow-up-right" size={14} color="var(--fg-tertiary)" />
            </div>
            <div style={{ fontSize: 12.5, color: 'var(--fg-secondary)', lineHeight: 1.6 }}>{w.desc}</div>
          </Card>
        ))}
      </div>

      {/* Pipeline table */}
      <div style={{ marginTop: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 10 }}>
          <h2 style={{ fontSize: 14, fontWeight: 500, margin: 0, color: 'var(--fg-primary)' }}>项目管道</h2>
          <Badge style={{ marginLeft: 8 }}>{PIPELINE.length}</Badge>
          <div style={{ flex: 1 }} />
          <Button size="sm" variant="ghost" trailing="arrow-right" onClick={() => onNavigate('screener')}>全部</Button>
        </div>
        <Card style={{ overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5, fontFamily: 'var(--font-sans)' }}>
            <thead>
              <tr style={{ background: 'var(--bg-surface)', borderBottom: '1px solid var(--border-default)' }}>
                {['公司', '阶段', '赛道', '轮次', '规模', '负责人', '进度', '更新'].map(h => (
                  <th key={h} style={{ textAlign: 'left', padding: '8px 12px', fontSize: 10.5, color: 'var(--fg-tertiary)', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {PIPELINE.map(d => <PipelineRow key={d.id} d={d} onClick={() => onNavigate('dd')} />)}
            </tbody>
          </table>
        </Card>
      </div>
    </div>
  );
};

const PipelineRow = ({ d, onClick }) => {
  const [hover, setHover] = useState(false);
  const stageTone = { '尽调中': 'info', 'IC 审议': 'warning', '初步接触': 'subtle', '已投': 'success', '已 Pass': 'subtle' }[d.stage];
  return (
    <tr
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onClick={onClick}
      style={{ cursor: 'pointer', background: hover ? 'var(--bg-hover)' : 'transparent', borderBottom: '1px solid var(--border-subtle)' }}
    >
      <td style={{ padding: '10px 12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 22, height: 22, borderRadius: 4, background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 600, color: 'var(--fg-secondary)' }}>{d.name.charAt(0)}</div>
          <div>
            <div style={{ color: 'var(--fg-primary)', fontWeight: 500 }}>{d.name}</div>
            <div style={{ fontSize: 10.5, color: 'var(--fg-tertiary)', fontFamily: 'var(--font-mono)' }}>{d.eng}</div>
          </div>
        </div>
      </td>
      <td style={{ padding: '10px 12px' }}><Badge tone={stageTone}>{d.stage}</Badge></td>
      <td style={{ padding: '10px 12px', color: 'var(--fg-secondary)' }}>{d.sector}</td>
      <td style={{ padding: '10px 12px', color: 'var(--fg-secondary)' }}>{d.round}</td>
      <td style={{ padding: '10px 12px', color: 'var(--fg-primary)', fontVariantNumeric: 'tabular-nums', fontFamily: 'var(--font-numeric)' }}>{d.size}</td>
      <td style={{ padding: '10px 12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <Avatar name={d.owner} size={18} />
          <span style={{ color: 'var(--fg-secondary)' }}>{d.owner}</span>
        </div>
      </td>
      <td style={{ padding: '10px 12px', minWidth: 100 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <ProgressBar value={d.progress} tone={d.progress === 100 ? 'success' : 'brand'} style={{ flex: 1 }} />
          <span style={{ fontSize: 11, color: 'var(--fg-tertiary)', fontFamily: 'var(--font-numeric)', minWidth: 28, textAlign: 'right' }}>{d.progress}%</span>
        </div>
      </td>
      <td style={{ padding: '10px 12px', color: 'var(--fg-tertiary)', fontSize: 11 }}>{d.updated}</td>
    </tr>
  );
};

window.Dashboard = Dashboard;
