# Handoff: 投资经理助手 AI 工作台 · v2 增量更新

> 这是 **v2 增量更新包**。如果你已经根据 v1 handoff 把设计集成到代码库,本包只包含 **自上一版以来修改的样式**,便于同步。

---

## 自 v1 以来的变更清单

共 3 处微调,全部是布局 / 颜色细节,不涉及组件结构或新功能。

### 1. Topbar · breadcrumb 防换行

**文件**:`src/Shell.jsx` · `Topbar` 组件
**问题**:面包屑在窄视口下会换行 / 挤压
**修改**:容器和每个 span 都加上 `whiteSpace: nowrap` + `flexShrink: 0`;chevron 图标也加 `flexShrink: 0`

对应 CSS (React 实现中):
```js
// breadcrumb 容器
{ display: 'flex', alignItems: 'center', gap: 6, flex: '0 0 auto', minWidth: 0, whiteSpace: 'nowrap', flexShrink: 0 }

// 每个 breadcrumb 文本
{ whiteSpace: 'nowrap', flexShrink: 0 }

// 分隔符 ChevronRight 图标
{ flexShrink: 0 }
```

### 2. DDReport · 尽调进度条防换行

**文件**:`src/DDReport.jsx` · 顶部 6 步进度条 (资料收集 / 财务核验 / 客户访谈 / 法务尽调 / 技术评估 / IC 准备)
**问题**:每个步骤标签在紧凑宽度下会换行
**修改**:每个 step 容器加 `whiteSpace: nowrap` + `flexShrink: 0`

```js
// 每个步骤的 div 容器
{ display: 'flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap', flexShrink: 0 }
```

### 3. Sidebar · 非激活项字体颜色降级

**文件**:`src/Shell.jsx` · `SidebarItem` 组件
**问题**:所有条目的 title 颜色都是 `--fg-primary`,激活项与未激活项层级不清晰
**修改**:未激活状态下 title 改为 `--fg-secondary`,hover 时回到 `--fg-primary`,加 120ms color transition

```js
// title 文本颜色逻辑
color: active
  ? 'var(--fg-primary)'           // 激活 — 最亮
  : (hover ? 'var(--fg-primary)'  // hover — 最亮
           : 'var(--fg-secondary)'), // 默认 — 次级灰

fontWeight: active ? 500 : 400,
transition: 'color 120ms ease',
```

对应的 token 值 (来自 `assets/colors_and_type.css`,暗色主题):
- `--fg-primary`:最亮文本(激活 / hover)
- `--fg-secondary`:次级文本(非激活默认)
- `--fg-tertiary`:最弱文本(meta / timestamp,本次未改)

---

## 集成建议

如果你之前把 v1 设计搬到了 React/Vue/SwiftUI/其他框架,这 3 处变更:

1. **全部是纯样式层改动**,不涉及组件 API、state、数据流
2. **只需要改两个文件**:`Topbar` 相关 + `SidebarItem` / 侧栏导航 + `DDReport` 顶部 stepper
3. **如果你用了 token / 主题系统**(推荐),把 SidebarItem 未激活态的字色变量从 primary 改为 secondary 即可

---

## 本包文件

- `投资经理助手.html` · 入口,展示改动后的完整原型
- `src/Shell.jsx` · 包含改动 ①(Topbar)和 ③(SidebarItem)
- `src/DDReport.jsx` · 包含改动 ②(进度条)
- 其余文件 (`primitives.jsx`, `data.jsx`, `AiPanel.jsx`, `Dashboard.jsx`, `Research.jsx`, `Memo.jsx`, `App.jsx`) 相对 v1 无样式改动,作为完整参照保留
- `assets/colors_and_type.css` · token 文件,无改动

---

## 运行原型

本包是一组 HTML + React (Babel 实时编译) 原型,**不是生产代码**。直接用浏览器打开 `投资经理助手.html` 即可预览改动后的完整工作台。

## 如果你需要完整重做 handoff

本包默认你已经有 v1 集成好的代码,仅做增量同步。如果你需要完整的 v1 级别 handoff(含所有组件、token、交互规范),告诉我,我可以输出完整版。
